/*
 * Copyright GoInstant, Inc. and other contributors. All rights reserved.
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
var cookieJar = {};
(function () {


    'use strict';

    var getPublicSuffix = function getPublicSuffix(domain) {
        /*
         * Copyright GoInstant, Inc. and other contributors. All rights reserved.
         * Permission is hereby granted, free of charge, to any person obtaining a copy
         * of this software and associated documentation files (the "Software"), to
         * deal in the Software without restriction, including without limitation the
         * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
         * sell copies of the Software, and to permit persons to whom the Software is
         * furnished to do so, subject to the following conditions:
         *
         * The above copyright notice and this permission notice shall be included in
         * all copies or substantial portions of the Software.
         *
         * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
         * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
         * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
         * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
         * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
         * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
         * IN THE SOFTWARE.
         */
        if (!domain) return null;
        if (domain.match(/^\./)) return null;

        domain = domain.toLowerCase();
        var parts = domain.split('.').reverse();

        var suffix = '';
        var suffixLen = 0;
        for (var i = 0; i < parts.length; i++) {
            var part = parts[i];
            var starstr = '*' + suffix;
            var partstr = part + suffix;

            if (index[starstr]) { // star rule matches
                suffixLen = i + 1;
                if (index[partstr] === false) { // exception rule matches (NB: false, not undefined)
                    suffixLen--;
                }
            } else if (index[partstr]) { // exact match, not exception
                suffixLen = i + 1;
            }

            suffix = '.' + part + suffix;
        }

        if (index['*' + suffix]) { // *.domain exists (e.g. *.kyoto.jp for domain='kyoto.jp');
            return null;
        }

        if (suffixLen && parts.length > suffixLen) {
            return parts.slice(0, suffixLen + 1).reverse().join('.');
        }

        return null;
    };

        cookieJar.getPublicSuffix = getPublicSuffix;
// The following generated structure is used under the MPL version 1.1
// See public-suffix.txt for more information

    var index = Object.freeze(
        {
            "ac": true,
            "com.ac": true,
            "edu.ac": true,
            "gov.ac": true,
            "net.ac": true,
            "mil.ac": true,
            "org.ac": true,
            "ad": true,
            "nom.ad": true,
            "ae": true,
            "co.ae": true,
            "net.ae": true,
            "org.ae": true,
            "sch.ae": true,
            "ac.ae": true,
            "gov.ae": true,
            "mil.ae": true,
            "aero": true,
            "accident-investigation.aero": true,
            "accident-prevention.aero": true,
            "aerobatic.aero": true,
            "aeroclub.aero": true,
            "aerodrome.aero": true,
            "agents.aero": true,
            "aircraft.aero": true,
            "airline.aero": true,
            "airport.aero": true,
            "air-surveillance.aero": true,
            "airtraffic.aero": true,
            "air-traffic-control.aero": true,
            "ambulance.aero": true,
            "amusement.aero": true,
            "association.aero": true,
            "author.aero": true,
            "ballooning.aero": true,
            "broker.aero": true,
            "caa.aero": true,
            "cargo.aero": true,
            "catering.aero": true,
            "certification.aero": true,
            "championship.aero": true,
            "charter.aero": true,
            "civilaviation.aero": true,
            "club.aero": true,
            "conference.aero": true,
            "consultant.aero": true,
            "consulting.aero": true,
            "control.aero": true,
            "council.aero": true,
            "crew.aero": true,
            "design.aero": true,
            "dgca.aero": true,
            "educator.aero": true,
            "emergency.aero": true,
            "engine.aero": true,
            "engineer.aero": true,
            "entertainment.aero": true,
            "equipment.aero": true,
            "exchange.aero": true,
            "express.aero": true,
            "federation.aero": true,
            "flight.aero": true,
            "freight.aero": true,
            "fuel.aero": true,
            "gliding.aero": true,
            "government.aero": true,
            "groundhandling.aero": true,
            "group.aero": true,
            "hanggliding.aero": true,
            "homebuilt.aero": true,
            "insurance.aero": true,
            "journal.aero": true,
            "journalist.aero": true,
            "leasing.aero": true,
            "logistics.aero": true,
            "magazine.aero": true,
            "maintenance.aero": true,
            "marketplace.aero": true,
            "media.aero": true,
            "microlight.aero": true,
            "modelling.aero": true,
            "navigation.aero": true,
            "parachuting.aero": true,
            "paragliding.aero": true,
            "passenger-association.aero": true,
            "pilot.aero": true,
            "press.aero": true,
            "production.aero": true,
            "recreation.aero": true,
            "repbody.aero": true,
            "res.aero": true,
            "research.aero": true,
            "rotorcraft.aero": true,
            "safety.aero": true,
            "scientist.aero": true,
            "services.aero": true,
            "show.aero": true,
            "skydiving.aero": true,
            "software.aero": true,
            "student.aero": true,
            "taxi.aero": true,
            "trader.aero": true,
            "trading.aero": true,
            "trainer.aero": true,
            "union.aero": true,
            "workinggroup.aero": true,
            "works.aero": true,
            "af": true,
            "gov.af": true,
            "com.af": true,
            "org.af": true,
            "net.af": true,
            "edu.af": true,
            "ag": true,
            "com.ag": true,
            "org.ag": true,
            "net.ag": true,
            "co.ag": true,
            "nom.ag": true,
            "ai": true,
            "off.ai": true,
            "com.ai": true,
            "net.ai": true,
            "org.ai": true,
            "al": true,
            "com.al": true,
            "edu.al": true,
            "gov.al": true,
            "mil.al": true,
            "net.al": true,
            "org.al": true,
            "am": true,
            "an": true,
            "com.an": true,
            "net.an": true,
            "org.an": true,
            "edu.an": true,
            "ao": true,
            "ed.ao": true,
            "gv.ao": true,
            "og.ao": true,
            "co.ao": true,
            "pb.ao": true,
            "it.ao": true,
            "aq": true,
            "*.ar": true,
            "congresodelalengua3.ar": false,
            "educ.ar": false,
            "gobiernoelectronico.ar": false,
            "mecon.ar": false,
            "nacion.ar": false,
            "nic.ar": false,
            "promocion.ar": false,
            "retina.ar": false,
            "uba.ar": false,
            "e164.arpa": true,
            "in-addr.arpa": true,
            "ip6.arpa": true,
            "iris.arpa": true,
            "uri.arpa": true,
            "urn.arpa": true,
            "as": true,
            "gov.as": true,
            "asia": true,
            "at": true,
            "ac.at": true,
            "co.at": true,
            "gv.at": true,
            "or.at": true,
            "com.au": true,
            "net.au": true,
            "org.au": true,
            "edu.au": true,
            "gov.au": true,
            "csiro.au": true,
            "asn.au": true,
            "id.au": true,
            "info.au": true,
            "conf.au": true,
            "oz.au": true,
            "act.au": true,
            "nsw.au": true,
            "nt.au": true,
            "qld.au": true,
            "sa.au": true,
            "tas.au": true,
            "vic.au": true,
            "wa.au": true,
            "act.edu.au": true,
            "nsw.edu.au": true,
            "nt.edu.au": true,
            "qld.edu.au": true,
            "sa.edu.au": true,
            "tas.edu.au": true,
            "vic.edu.au": true,
            "wa.edu.au": true,
            "act.gov.au": true,
            "nt.gov.au": true,
            "qld.gov.au": true,
            "sa.gov.au": true,
            "tas.gov.au": true,
            "vic.gov.au": true,
            "wa.gov.au": true,
            "aw": true,
            "com.aw": true,
            "ax": true,
            "az": true,
            "com.az": true,
            "net.az": true,
            "int.az": true,
            "gov.az": true,
            "org.az": true,
            "edu.az": true,
            "info.az": true,
            "pp.az": true,
            "mil.az": true,
            "name.az": true,
            "pro.az": true,
            "biz.az": true,
            "ba": true,
            "org.ba": true,
            "net.ba": true,
            "edu.ba": true,
            "gov.ba": true,
            "mil.ba": true,
            "unsa.ba": true,
            "unbi.ba": true,
            "co.ba": true,
            "com.ba": true,
            "rs.ba": true,
            "bb": true,
            "biz.bb": true,
            "com.bb": true,
            "edu.bb": true,
            "gov.bb": true,
            "info.bb": true,
            "net.bb": true,
            "org.bb": true,
            "store.bb": true,
            "*.bd": true,
            "be": true,
            "ac.be": true,
            "bf": true,
            "gov.bf": true,
            "bg": true,
            "a.bg": true,
            "b.bg": true,
            "c.bg": true,
            "d.bg": true,
            "e.bg": true,
            "f.bg": true,
            "g.bg": true,
            "h.bg": true,
            "i.bg": true,
            "j.bg": true,
            "k.bg": true,
            "l.bg": true,
            "m.bg": true,
            "n.bg": true,
            "o.bg": true,
            "p.bg": true,
            "q.bg": true,
            "r.bg": true,
            "s.bg": true,
            "t.bg": true,
            "u.bg": true,
            "v.bg": true,
            "w.bg": true,
            "x.bg": true,
            "y.bg": true,
            "z.bg": true,
            "0.bg": true,
            "1.bg": true,
            "2.bg": true,
            "3.bg": true,
            "4.bg": true,
            "5.bg": true,
            "6.bg": true,
            "7.bg": true,
            "8.bg": true,
            "9.bg": true,
            "bh": true,
            "com.bh": true,
            "edu.bh": true,
            "net.bh": true,
            "org.bh": true,
            "gov.bh": true,
            "bi": true,
            "co.bi": true,
            "com.bi": true,
            "edu.bi": true,
            "or.bi": true,
            "org.bi": true,
            "biz": true,
            "bj": true,
            "asso.bj": true,
            "barreau.bj": true,
            "gouv.bj": true,
            "bm": true,
            "com.bm": true,
            "edu.bm": true,
            "gov.bm": true,
            "net.bm": true,
            "org.bm": true,
            "*.bn": true,
            "bo": true,
            "com.bo": true,
            "edu.bo": true,
            "gov.bo": true,
            "gob.bo": true,
            "int.bo": true,
            "org.bo": true,
            "net.bo": true,
            "mil.bo": true,
            "tv.bo": true,
            "br": true,
            "adm.br": true,
            "adv.br": true,
            "agr.br": true,
            "am.br": true,
            "arq.br": true,
            "art.br": true,
            "ato.br": true,
            "b.br": true,
            "bio.br": true,
            "blog.br": true,
            "bmd.br": true,
            "can.br": true,
            "cim.br": true,
            "cng.br": true,
            "cnt.br": true,
            "com.br": true,
            "coop.br": true,
            "ecn.br": true,
            "edu.br": true,
            "emp.br": true,
            "eng.br": true,
            "esp.br": true,
            "etc.br": true,
            "eti.br": true,
            "far.br": true,
            "flog.br": true,
            "fm.br": true,
            "fnd.br": true,
            "fot.br": true,
            "fst.br": true,
            "g12.br": true,
            "ggf.br": true,
            "gov.br": true,
            "imb.br": true,
            "ind.br": true,
            "inf.br": true,
            "jor.br": true,
            "jus.br": true,
            "lel.br": true,
            "mat.br": true,
            "med.br": true,
            "mil.br": true,
            "mus.br": true,
            "net.br": true,
            "nom.br": true,
            "not.br": true,
            "ntr.br": true,
            "odo.br": true,
            "org.br": true,
            "ppg.br": true,
            "pro.br": true,
            "psc.br": true,
            "psi.br": true,
            "qsl.br": true,
            "radio.br": true,
            "rec.br": true,
            "slg.br": true,
            "srv.br": true,
            "taxi.br": true,
            "teo.br": true,
            "tmp.br": true,
            "trd.br": true,
            "tur.br": true,
            "tv.br": true,
            "vet.br": true,
            "vlog.br": true,
            "wiki.br": true,
            "zlg.br": true,
            "bs": true,
            "com.bs": true,
            "net.bs": true,
            "org.bs": true,
            "edu.bs": true,
            "gov.bs": true,
            "bt": true,
            "com.bt": true,
            "edu.bt": true,
            "gov.bt": true,
            "net.bt": true,
            "org.bt": true,
            "bw": true,
            "co.bw": true,
            "org.bw": true,
            "by": true,
            "gov.by": true,
            "mil.by": true,
            "com.by": true,
            "of.by": true,
            "bz": true,
            "com.bz": true,
            "net.bz": true,
            "org.bz": true,
            "edu.bz": true,
            "gov.bz": true,
            "ca": true,
            "ab.ca": true,
            "bc.ca": true,
            "mb.ca": true,
            "nb.ca": true,
            "nf.ca": true,
            "nl.ca": true,
            "ns.ca": true,
            "nt.ca": true,
            "nu.ca": true,
            "on.ca": true,
            "pe.ca": true,
            "qc.ca": true,
            "sk.ca": true,
            "yk.ca": true,
            "gc.ca": true,
            "cat": true,
            "cc": true,
            "cd": true,
            "gov.cd": true,
            "cf": true,
            "cg": true,
            "ch": true,
            "ci": true,
            "org.ci": true,
            "or.ci": true,
            "com.ci": true,
            "co.ci": true,
            "edu.ci": true,
            "ed.ci": true,
            "ac.ci": true,
            "net.ci": true,
            "go.ci": true,
            "asso.ci": true,
            "xn--aroport-bya.ci": true,
            "int.ci": true,
            "presse.ci": true,
            "md.ci": true,
            "gouv.ci": true,
            "*.ck": true,
            "www.ck": false,
            "cl": true,
            "gov.cl": true,
            "gob.cl": true,
            "co.cl": true,
            "mil.cl": true,
            "cm": true,
            "gov.cm": true,
            "cn": true,
            "ac.cn": true,
            "com.cn": true,
            "edu.cn": true,
            "gov.cn": true,
            "net.cn": true,
            "org.cn": true,
            "mil.cn": true,
            "xn--55qx5d.cn": true,
            "xn--io0a7i.cn": true,
            "xn--od0alg.cn": true,
            "ah.cn": true,
            "bj.cn": true,
            "cq.cn": true,
            "fj.cn": true,
            "gd.cn": true,
            "gs.cn": true,
            "gz.cn": true,
            "gx.cn": true,
            "ha.cn": true,
            "hb.cn": true,
            "he.cn": true,
            "hi.cn": true,
            "hl.cn": true,
            "hn.cn": true,
            "jl.cn": true,
            "js.cn": true,
            "jx.cn": true,
            "ln.cn": true,
            "nm.cn": true,
            "nx.cn": true,
            "qh.cn": true,
            "sc.cn": true,
            "sd.cn": true,
            "sh.cn": true,
            "sn.cn": true,
            "sx.cn": true,
            "tj.cn": true,
            "xj.cn": true,
            "xz.cn": true,
            "yn.cn": true,
            "zj.cn": true,
            "hk.cn": true,
            "mo.cn": true,
            "tw.cn": true,
            "co": true,
            "arts.co": true,
            "com.co": true,
            "edu.co": true,
            "firm.co": true,
            "gov.co": true,
            "info.co": true,
            "int.co": true,
            "mil.co": true,
            "net.co": true,
            "nom.co": true,
            "org.co": true,
            "rec.co": true,
            "web.co": true,
            "com": true,
            "coop": true,
            "cr": true,
            "ac.cr": true,
            "co.cr": true,
            "ed.cr": true,
            "fi.cr": true,
            "go.cr": true,
            "or.cr": true,
            "sa.cr": true,
            "cu": true,
            "com.cu": true,
            "edu.cu": true,
            "org.cu": true,
            "net.cu": true,
            "gov.cu": true,
            "inf.cu": true,
            "cv": true,
            "cx": true,
            "gov.cx": true,
            "*.cy": true,
            "cz": true,
            "de": true,
            "dj": true,
            "dk": true,
            "dm": true,
            "com.dm": true,
            "net.dm": true,
            "org.dm": true,
            "edu.dm": true,
            "gov.dm": true,
            "do": true,
            "art.do": true,
            "com.do": true,
            "edu.do": true,
            "gob.do": true,
            "gov.do": true,
            "mil.do": true,
            "net.do": true,
            "org.do": true,
            "sld.do": true,
            "web.do": true,
            "dz": true,
            "com.dz": true,
            "org.dz": true,
            "net.dz": true,
            "gov.dz": true,
            "edu.dz": true,
            "asso.dz": true,
            "pol.dz": true,
            "art.dz": true,
            "ec": true,
            "com.ec": true,
            "info.ec": true,
            "net.ec": true,
            "fin.ec": true,
            "k12.ec": true,
            "med.ec": true,
            "pro.ec": true,
            "org.ec": true,
            "edu.ec": true,
            "gov.ec": true,
            "gob.ec": true,
            "mil.ec": true,
            "edu": true,
            "ee": true,
            "edu.ee": true,
            "gov.ee": true,
            "riik.ee": true,
            "lib.ee": true,
            "med.ee": true,
            "com.ee": true,
            "pri.ee": true,
            "aip.ee": true,
            "org.ee": true,
            "fie.ee": true,
            "eg": true,
            "com.eg": true,
            "edu.eg": true,
            "eun.eg": true,
            "gov.eg": true,
            "mil.eg": true,
            "name.eg": true,
            "net.eg": true,
            "org.eg": true,
            "sci.eg": true,
            "*.er": true,
            "es": true,
            "com.es": true,
            "nom.es": true,
            "org.es": true,
            "gob.es": true,
            "edu.es": true,
            "*.et": true,
            "eu": true,
            "fi": true,
            "aland.fi": true,
            "*.fj": true,
            "*.fk": true,
            "fm": true,
            "fo": true,
            "fr": true,
            "com.fr": true,
            "asso.fr": true,
            "nom.fr": true,
            "prd.fr": true,
            "presse.fr": true,
            "tm.fr": true,
            "aeroport.fr": true,
            "assedic.fr": true,
            "avocat.fr": true,
            "avoues.fr": true,
            "cci.fr": true,
            "chambagri.fr": true,
            "chirurgiens-dentistes.fr": true,
            "experts-comptables.fr": true,
            "geometre-expert.fr": true,
            "gouv.fr": true,
            "greta.fr": true,
            "huissier-justice.fr": true,
            "medecin.fr": true,
            "notaires.fr": true,
            "pharmacien.fr": true,
            "port.fr": true,
            "veterinaire.fr": true,
            "ga": true,
            "gd": true,
            "ge": true,
            "com.ge": true,
            "edu.ge": true,
            "gov.ge": true,
            "org.ge": true,
            "mil.ge": true,
            "net.ge": true,
            "pvt.ge": true,
            "gf": true,
            "gg": true,
            "co.gg": true,
            "org.gg": true,
            "net.gg": true,
            "sch.gg": true,
            "gov.gg": true,
            "gh": true,
            "com.gh": true,
            "edu.gh": true,
            "gov.gh": true,
            "org.gh": true,
            "mil.gh": true,
            "gi": true,
            "com.gi": true,
            "ltd.gi": true,
            "gov.gi": true,
            "mod.gi": true,
            "edu.gi": true,
            "org.gi": true,
            "gl": true,
            "gm": true,
            "ac.gn": true,
            "com.gn": true,
            "edu.gn": true,
            "gov.gn": true,
            "org.gn": true,
            "net.gn": true,
            "gov": true,
            "gp": true,
            "com.gp": true,
            "net.gp": true,
            "mobi.gp": true,
            "edu.gp": true,
            "org.gp": true,
            "asso.gp": true,
            "gq": true,
            "gr": true,
            "com.gr": true,
            "edu.gr": true,
            "net.gr": true,
            "org.gr": true,
            "gov.gr": true,
            "gs": true,
            "*.gt": true,
            "www.gt": false,
            "*.gu": true,
            "gw": true,
            "gy": true,
            "co.gy": true,
            "com.gy": true,
            "net.gy": true,
            "hk": true,
            "com.hk": true,
            "edu.hk": true,
            "gov.hk": true,
            "idv.hk": true,
            "net.hk": true,
            "org.hk": true,
            "xn--55qx5d.hk": true,
            "xn--wcvs22d.hk": true,
            "xn--lcvr32d.hk": true,
            "xn--mxtq1m.hk": true,
            "xn--gmqw5a.hk": true,
            "xn--ciqpn.hk": true,
            "xn--gmq050i.hk": true,
            "xn--zf0avx.hk": true,
            "xn--io0a7i.hk": true,
            "xn--mk0axi.hk": true,
            "xn--od0alg.hk": true,
            "xn--od0aq3b.hk": true,
            "xn--tn0ag.hk": true,
            "xn--uc0atv.hk": true,
            "xn--uc0ay4a.hk": true,
            "hm": true,
            "hn": true,
            "com.hn": true,
            "edu.hn": true,
            "org.hn": true,
            "net.hn": true,
            "mil.hn": true,
            "gob.hn": true,
            "hr": true,
            "iz.hr": true,
            "from.hr": true,
            "name.hr": true,
            "com.hr": true,
            "ht": true,
            "com.ht": true,
            "shop.ht": true,
            "firm.ht": true,
            "info.ht": true,
            "adult.ht": true,
            "net.ht": true,
            "pro.ht": true,
            "org.ht": true,
            "med.ht": true,
            "art.ht": true,
            "coop.ht": true,
            "pol.ht": true,
            "asso.ht": true,
            "edu.ht": true,
            "rel.ht": true,
            "gouv.ht": true,
            "perso.ht": true,
            "hu": true,
            "co.hu": true,
            "info.hu": true,
            "org.hu": true,
            "priv.hu": true,
            "sport.hu": true,
            "tm.hu": true,
            "2000.hu": true,
            "agrar.hu": true,
            "bolt.hu": true,
            "casino.hu": true,
            "city.hu": true,
            "erotica.hu": true,
            "erotika.hu": true,
            "film.hu": true,
            "forum.hu": true,
            "games.hu": true,
            "hotel.hu": true,
            "ingatlan.hu": true,
            "jogasz.hu": true,
            "konyvelo.hu": true,
            "lakas.hu": true,
            "media.hu": true,
            "news.hu": true,
            "reklam.hu": true,
            "sex.hu": true,
            "shop.hu": true,
            "suli.hu": true,
            "szex.hu": true,
            "tozsde.hu": true,
            "utazas.hu": true,
            "video.hu": true,
            "id": true,
            "ac.id": true,
            "co.id": true,
            "go.id": true,
            "mil.id": true,
            "net.id": true,
            "or.id": true,
            "sch.id": true,
            "web.id": true,
            "ie": true,
            "gov.ie": true,
            "*.il": true,
            "im": true,
            "co.im": true,
            "ltd.co.im": true,
            "plc.co.im": true,
            "net.im": true,
            "gov.im": true,
            "org.im": true,
            "nic.im": true,
            "ac.im": true,
            "in": true,
            "co.in": true,
            "firm.in": true,
            "net.in": true,
            "org.in": true,
            "gen.in": true,
            "ind.in": true,
            "nic.in": true,
            "ac.in": true,
            "edu.in": true,
            "res.in": true,
            "gov.in": true,
            "mil.in": true,
            "info": true,
            "int": true,
            "eu.int": true,
            "io": true,
            "com.io": true,
            "iq": true,
            "gov.iq": true,
            "edu.iq": true,
            "mil.iq": true,
            "com.iq": true,
            "org.iq": true,
            "net.iq": true,
            "ir": true,
            "ac.ir": true,
            "co.ir": true,
            "gov.ir": true,
            "id.ir": true,
            "net.ir": true,
            "org.ir": true,
            "sch.ir": true,
            "xn--mgba3a4f16a.ir": true,
            "xn--mgba3a4fra.ir": true,
            "is": true,
            "net.is": true,
            "com.is": true,
            "edu.is": true,
            "gov.is": true,
            "org.is": true,
            "int.is": true,
            "it": true,
            "gov.it": true,
            "edu.it": true,
            "agrigento.it": true,
            "ag.it": true,
            "alessandria.it": true,
            "al.it": true,
            "ancona.it": true,
            "an.it": true,
            "aosta.it": true,
            "aoste.it": true,
            "ao.it": true,
            "arezzo.it": true,
            "ar.it": true,
            "ascoli-piceno.it": true,
            "ascolipiceno.it": true,
            "ap.it": true,
            "asti.it": true,
            "at.it": true,
            "avellino.it": true,
            "av.it": true,
            "bari.it": true,
            "ba.it": true,
            "andria-barletta-trani.it": true,
            "andriabarlettatrani.it": true,
            "trani-barletta-andria.it": true,
            "tranibarlettaandria.it": true,
            "barletta-trani-andria.it": true,
            "barlettatraniandria.it": true,
            "andria-trani-barletta.it": true,
            "andriatranibarletta.it": true,
            "trani-andria-barletta.it": true,
            "traniandriabarletta.it": true,
            "bt.it": true,
            "belluno.it": true,
            "bl.it": true,
            "benevento.it": true,
            "bn.it": true,
            "bergamo.it": true,
            "bg.it": true,
            "biella.it": true,
            "bi.it": true,
            "bologna.it": true,
            "bo.it": true,
            "bolzano.it": true,
            "bozen.it": true,
            "balsan.it": true,
            "alto-adige.it": true,
            "altoadige.it": true,
            "suedtirol.it": true,
            "bz.it": true,
            "brescia.it": true,
            "bs.it": true,
            "brindisi.it": true,
            "br.it": true,
            "cagliari.it": true,
            "ca.it": true,
            "caltanissetta.it": true,
            "cl.it": true,
            "campobasso.it": true,
            "cb.it": true,
            "carboniaiglesias.it": true,
            "carbonia-iglesias.it": true,
            "iglesias-carbonia.it": true,
            "iglesiascarbonia.it": true,
            "ci.it": true,
            "caserta.it": true,
            "ce.it": true,
            "catania.it": true,
            "ct.it": true,
            "catanzaro.it": true,
            "cz.it": true,
            "chieti.it": true,
            "ch.it": true,
            "como.it": true,
            "co.it": true,
            "cosenza.it": true,
            "cs.it": true,
            "cremona.it": true,
            "cr.it": true,
            "crotone.it": true,
            "kr.it": true,
            "cuneo.it": true,
            "cn.it": true,
            "dell-ogliastra.it": true,
            "dellogliastra.it": true,
            "ogliastra.it": true,
            "og.it": true,
            "enna.it": true,
            "en.it": true,
            "ferrara.it": true,
            "fe.it": true,
            "fermo.it": true,
            "fm.it": true,
            "firenze.it": true,
            "florence.it": true,
            "fi.it": true,
            "foggia.it": true,
            "fg.it": true,
            "forli-cesena.it": true,
            "forlicesena.it": true,
            "cesena-forli.it": true,
            "cesenaforli.it": true,
            "fc.it": true,
            "frosinone.it": true,
            "fr.it": true,
            "genova.it": true,
            "genoa.it": true,
            "ge.it": true,
            "gorizia.it": true,
            "go.it": true,
            "grosseto.it": true,
            "gr.it": true,
            "imperia.it": true,
            "im.it": true,
            "isernia.it": true,
            "is.it": true,
            "laquila.it": true,
            "aquila.it": true,
            "aq.it": true,
            "la-spezia.it": true,
            "laspezia.it": true,
            "sp.it": true,
            "latina.it": true,
            "lt.it": true,
            "lecce.it": true,
            "le.it": true,
            "lecco.it": true,
            "lc.it": true,
            "livorno.it": true,
            "li.it": true,
            "lodi.it": true,
            "lo.it": true,
            "lucca.it": true,
            "lu.it": true,
            "macerata.it": true,
            "mc.it": true,
            "mantova.it": true,
            "mn.it": true,
            "massa-carrara.it": true,
            "massacarrara.it": true,
            "carrara-massa.it": true,
            "carraramassa.it": true,
            "ms.it": true,
            "matera.it": true,
            "mt.it": true,
            "medio-campidano.it": true,
            "mediocampidano.it": true,
            "campidano-medio.it": true,
            "campidanomedio.it": true,
            "vs.it": true,
            "messina.it": true,
            "me.it": true,
            "milano.it": true,
            "milan.it": true,
            "mi.it": true,
            "modena.it": true,
            "mo.it": true,
            "monza.it": true,
            "monza-brianza.it": true,
            "monzabrianza.it": true,
            "monzaebrianza.it": true,
            "monzaedellabrianza.it": true,
            "monza-e-della-brianza.it": true,
            "mb.it": true,
            "napoli.it": true,
            "naples.it": true,
            "na.it": true,
            "novara.it": true,
            "no.it": true,
            "nuoro.it": true,
            "nu.it": true,
            "oristano.it": true,
            "or.it": true,
            "padova.it": true,
            "padua.it": true,
            "pd.it": true,
            "palermo.it": true,
            "pa.it": true,
            "parma.it": true,
            "pr.it": true,
            "pavia.it": true,
            "pv.it": true,
            "perugia.it": true,
            "pg.it": true,
            "pescara.it": true,
            "pe.it": true,
            "pesaro-urbino.it": true,
            "pesarourbino.it": true,
            "urbino-pesaro.it": true,
            "urbinopesaro.it": true,
            "pu.it": true,
            "piacenza.it": true,
            "pc.it": true,
            "pisa.it": true,
            "pi.it": true,
            "pistoia.it": true,
            "pt.it": true,
            "pordenone.it": true,
            "pn.it": true,
            "potenza.it": true,
            "pz.it": true,
            "prato.it": true,
            "po.it": true,
            "ragusa.it": true,
            "rg.it": true,
            "ravenna.it": true,
            "ra.it": true,
            "reggio-calabria.it": true,
            "reggiocalabria.it": true,
            "rc.it": true,
            "reggio-emilia.it": true,
            "reggioemilia.it": true,
            "re.it": true,
            "rieti.it": true,
            "ri.it": true,
            "rimini.it": true,
            "rn.it": true,
            "roma.it": true,
            "rome.it": true,
            "rm.it": true,
            "rovigo.it": true,
            "ro.it": true,
            "salerno.it": true,
            "sa.it": true,
            "sassari.it": true,
            "ss.it": true,
            "savona.it": true,
            "sv.it": true,
            "siena.it": true,
            "si.it": true,
            "siracusa.it": true,
            "sr.it": true,
            "sondrio.it": true,
            "so.it": true,
            "taranto.it": true,
            "ta.it": true,
            "tempio-olbia.it": true,
            "tempioolbia.it": true,
            "olbia-tempio.it": true,
            "olbiatempio.it": true,
            "ot.it": true,
            "teramo.it": true,
            "te.it": true,
            "terni.it": true,
            "tr.it": true,
            "torino.it": true,
            "turin.it": true,
            "to.it": true,
            "trapani.it": true,
            "tp.it": true,
            "trento.it": true,
            "trentino.it": true,
            "tn.it": true,
            "treviso.it": true,
            "tv.it": true,
            "trieste.it": true,
            "ts.it": true,
            "udine.it": true,
            "ud.it": true,
            "varese.it": true,
            "va.it": true,
            "venezia.it": true,
            "venice.it": true,
            "ve.it": true,
            "verbania.it": true,
            "vb.it": true,
            "vercelli.it": true,
            "vc.it": true,
            "verona.it": true,
            "vr.it": true,
            "vibo-valentia.it": true,
            "vibovalentia.it": true,
            "vv.it": true,
            "vicenza.it": true,
            "vi.it": true,
            "viterbo.it": true,
            "vt.it": true,
            "je": true,
            "co.je": true,
            "org.je": true,
            "net.je": true,
            "sch.je": true,
            "gov.je": true,
            "*.jm": true,
            "jo": true,
            "com.jo": true,
            "org.jo": true,
            "net.jo": true,
            "edu.jo": true,
            "sch.jo": true,
            "gov.jo": true,
            "mil.jo": true,
            "name.jo": true,
            "jobs": true,
            "jp": true,
            "ac.jp": true,
            "ad.jp": true,
            "co.jp": true,
            "ed.jp": true,
            "go.jp": true,
            "gr.jp": true,
            "lg.jp": true,
            "ne.jp": true,
            "or.jp": true,
            "*.aichi.jp": true,
            "*.akita.jp": true,
            "*.aomori.jp": true,
            "*.chiba.jp": true,
            "*.ehime.jp": true,
            "*.fukui.jp": true,
            "*.fukuoka.jp": true,
            "*.fukushima.jp": true,
            "*.gifu.jp": true,
            "*.gunma.jp": true,
            "*.hiroshima.jp": true,
            "*.hokkaido.jp": true,
            "*.hyogo.jp": true,
            "*.ibaraki.jp": true,
            "*.ishikawa.jp": true,
            "*.iwate.jp": true,
            "*.kagawa.jp": true,
            "*.kagoshima.jp": true,
            "*.kanagawa.jp": true,
            "*.kawasaki.jp": true,
            "*.kitakyushu.jp": true,
            "*.kobe.jp": true,
            "*.kochi.jp": true,
            "*.kumamoto.jp": true,
            "*.kyoto.jp": true,
            "*.mie.jp": true,
            "*.miyagi.jp": true,
            "*.miyazaki.jp": true,
            "*.nagano.jp": true,
            "*.nagasaki.jp": true,
            "*.nagoya.jp": true,
            "*.nara.jp": true,
            "*.niigata.jp": true,
            "*.oita.jp": true,
            "*.okayama.jp": true,
            "*.okinawa.jp": true,
            "*.osaka.jp": true,
            "*.saga.jp": true,
            "*.saitama.jp": true,
            "*.sapporo.jp": true,
            "*.sendai.jp": true,
            "*.shiga.jp": true,
            "*.shimane.jp": true,
            "*.shizuoka.jp": true,
            "*.tochigi.jp": true,
            "*.tokushima.jp": true,
            "*.tokyo.jp": true,
            "*.tottori.jp": true,
            "*.toyama.jp": true,
            "*.wakayama.jp": true,
            "*.yamagata.jp": true,
            "*.yamaguchi.jp": true,
            "*.yamanashi.jp": true,
            "*.yokohama.jp": true,
            "metro.tokyo.jp": false,
            "pref.aichi.jp": false,
            "pref.akita.jp": false,
            "pref.aomori.jp": false,
            "pref.chiba.jp": false,
            "pref.ehime.jp": false,
            "pref.fukui.jp": false,
            "pref.fukuoka.jp": false,
            "pref.fukushima.jp": false,
            "pref.gifu.jp": false,
            "pref.gunma.jp": false,
            "pref.hiroshima.jp": false,
            "pref.hokkaido.jp": false,
            "pref.hyogo.jp": false,
            "pref.ibaraki.jp": false,
            "pref.ishikawa.jp": false,
            "pref.iwate.jp": false,
            "pref.kagawa.jp": false,
            "pref.kagoshima.jp": false,
            "pref.kanagawa.jp": false,
            "pref.kochi.jp": false,
            "pref.kumamoto.jp": false,
            "pref.kyoto.jp": false,
            "pref.mie.jp": false,
            "pref.miyagi.jp": false,
            "pref.miyazaki.jp": false,
            "pref.nagano.jp": false,
            "pref.nagasaki.jp": false,
            "pref.nara.jp": false,
            "pref.niigata.jp": false,
            "pref.oita.jp": false,
            "pref.okayama.jp": false,
            "pref.okinawa.jp": false,
            "pref.osaka.jp": false,
            "pref.saga.jp": false,
            "pref.saitama.jp": false,
            "pref.shiga.jp": false,
            "pref.shimane.jp": false,
            "pref.shizuoka.jp": false,
            "pref.tochigi.jp": false,
            "pref.tokushima.jp": false,
            "pref.tottori.jp": false,
            "pref.toyama.jp": false,
            "pref.wakayama.jp": false,
            "pref.yamagata.jp": false,
            "pref.yamaguchi.jp": false,
            "pref.yamanashi.jp": false,
            "city.chiba.jp": false,
            "city.fukuoka.jp": false,
            "city.hiroshima.jp": false,
            "city.kawasaki.jp": false,
            "city.kitakyushu.jp": false,
            "city.kobe.jp": false,
            "city.kyoto.jp": false,
            "city.nagoya.jp": false,
            "city.niigata.jp": false,
            "city.okayama.jp": false,
            "city.osaka.jp": false,
            "city.saitama.jp": false,
            "city.sapporo.jp": false,
            "city.sendai.jp": false,
            "city.shizuoka.jp": false,
            "city.yokohama.jp": false,
            "*.ke": true,
            "kg": true,
            "org.kg": true,
            "net.kg": true,
            "com.kg": true,
            "edu.kg": true,
            "gov.kg": true,
            "mil.kg": true,
            "*.kh": true,
            "ki": true,
            "edu.ki": true,
            "biz.ki": true,
            "net.ki": true,
            "org.ki": true,
            "gov.ki": true,
            "info.ki": true,
            "com.ki": true,
            "km": true,
            "org.km": true,
            "nom.km": true,
            "gov.km": true,
            "prd.km": true,
            "tm.km": true,
            "edu.km": true,
            "mil.km": true,
            "ass.km": true,
            "com.km": true,
            "coop.km": true,
            "asso.km": true,
            "presse.km": true,
            "medecin.km": true,
            "notaires.km": true,
            "pharmaciens.km": true,
            "veterinaire.km": true,
            "gouv.km": true,
            "kn": true,
            "net.kn": true,
            "org.kn": true,
            "edu.kn": true,
            "gov.kn": true,
            "com.kp": true,
            "edu.kp": true,
            "gov.kp": true,
            "org.kp": true,
            "rep.kp": true,
            "tra.kp": true,
            "kr": true,
            "ac.kr": true,
            "co.kr": true,
            "es.kr": true,
            "go.kr": true,
            "hs.kr": true,
            "kg.kr": true,
            "mil.kr": true,
            "ms.kr": true,
            "ne.kr": true,
            "or.kr": true,
            "pe.kr": true,
            "re.kr": true,
            "sc.kr": true,
            "busan.kr": true,
            "chungbuk.kr": true,
            "chungnam.kr": true,
            "daegu.kr": true,
            "daejeon.kr": true,
            "gangwon.kr": true,
            "gwangju.kr": true,
            "gyeongbuk.kr": true,
            "gyeonggi.kr": true,
            "gyeongnam.kr": true,
            "incheon.kr": true,
            "jeju.kr": true,
            "jeonbuk.kr": true,
            "jeonnam.kr": true,
            "seoul.kr": true,
            "ulsan.kr": true,
            "*.kw": true,
            "ky": true,
            "edu.ky": true,
            "gov.ky": true,
            "com.ky": true,
            "org.ky": true,
            "net.ky": true,
            "kz": true,
            "org.kz": true,
            "edu.kz": true,
            "net.kz": true,
            "gov.kz": true,
            "mil.kz": true,
            "com.kz": true,
            "la": true,
            "int.la": true,
            "net.la": true,
            "info.la": true,
            "edu.la": true,
            "gov.la": true,
            "per.la": true,
            "com.la": true,
            "org.la": true,
            "com.lb": true,
            "edu.lb": true,
            "gov.lb": true,
            "net.lb": true,
            "org.lb": true,
            "lc": true,
            "com.lc": true,
            "net.lc": true,
            "co.lc": true,
            "org.lc": true,
            "edu.lc": true,
            "gov.lc": true,
            "li": true,
            "lk": true,
            "gov.lk": true,
            "sch.lk": true,
            "net.lk": true,
            "int.lk": true,
            "com.lk": true,
            "org.lk": true,
            "edu.lk": true,
            "ngo.lk": true,
            "soc.lk": true,
            "web.lk": true,
            "ltd.lk": true,
            "assn.lk": true,
            "grp.lk": true,
            "hotel.lk": true,
            "com.lr": true,
            "edu.lr": true,
            "gov.lr": true,
            "org.lr": true,
            "net.lr": true,
            "ls": true,
            "co.ls": true,
            "org.ls": true,
            "lt": true,
            "gov.lt": true,
            "lu": true,
            "lv": true,
            "com.lv": true,
            "edu.lv": true,
            "gov.lv": true,
            "org.lv": true,
            "mil.lv": true,
            "id.lv": true,
            "net.lv": true,
            "asn.lv": true,
            "conf.lv": true,
            "ly": true,
            "com.ly": true,
            "net.ly": true,
            "gov.ly": true,
            "plc.ly": true,
            "edu.ly": true,
            "sch.ly": true,
            "med.ly": true,
            "org.ly": true,
            "id.ly": true,
            "ma": true,
            "co.ma": true,
            "net.ma": true,
            "gov.ma": true,
            "org.ma": true,
            "ac.ma": true,
            "press.ma": true,
            "mc": true,
            "tm.mc": true,
            "asso.mc": true,
            "md": true,
            "me": true,
            "co.me": true,
            "net.me": true,
            "org.me": true,
            "edu.me": true,
            "ac.me": true,
            "gov.me": true,
            "its.me": true,
            "priv.me": true,
            "mg": true,
            "org.mg": true,
            "nom.mg": true,
            "gov.mg": true,
            "prd.mg": true,
            "tm.mg": true,
            "edu.mg": true,
            "mil.mg": true,
            "com.mg": true,
            "mh": true,
            "mil": true,
            "mk": true,
            "com.mk": true,
            "org.mk": true,
            "net.mk": true,
            "edu.mk": true,
            "gov.mk": true,
            "inf.mk": true,
            "name.mk": true,
            "ml": true,
            "com.ml": true,
            "edu.ml": true,
            "gouv.ml": true,
            "gov.ml": true,
            "net.ml": true,
            "org.ml": true,
            "presse.ml": true,
            "*.mm": true,
            "mn": true,
            "gov.mn": true,
            "edu.mn": true,
            "org.mn": true,
            "mo": true,
            "com.mo": true,
            "net.mo": true,
            "org.mo": true,
            "edu.mo": true,
            "gov.mo": true,
            "mobi": true,
            "mp": true,
            "mq": true,
            "mr": true,
            "gov.mr": true,
            "ms": true,
            "*.mt": true,
            "mu": true,
            "com.mu": true,
            "net.mu": true,
            "org.mu": true,
            "gov.mu": true,
            "ac.mu": true,
            "co.mu": true,
            "or.mu": true,
            "museum": true,
            "academy.museum": true,
            "agriculture.museum": true,
            "air.museum": true,
            "airguard.museum": true,
            "alabama.museum": true,
            "alaska.museum": true,
            "amber.museum": true,
            "ambulance.museum": true,
            "american.museum": true,
            "americana.museum": true,
            "americanantiques.museum": true,
            "americanart.museum": true,
            "amsterdam.museum": true,
            "and.museum": true,
            "annefrank.museum": true,
            "anthro.museum": true,
            "anthropology.museum": true,
            "antiques.museum": true,
            "aquarium.museum": true,
            "arboretum.museum": true,
            "archaeological.museum": true,
            "archaeology.museum": true,
            "architecture.museum": true,
            "art.museum": true,
            "artanddesign.museum": true,
            "artcenter.museum": true,
            "artdeco.museum": true,
            "arteducation.museum": true,
            "artgallery.museum": true,
            "arts.museum": true,
            "artsandcrafts.museum": true,
            "asmatart.museum": true,
            "assassination.museum": true,
            "assisi.museum": true,
            "association.museum": true,
            "astronomy.museum": true,
            "atlanta.museum": true,
            "austin.museum": true,
            "australia.museum": true,
            "automotive.museum": true,
            "aviation.museum": true,
            "axis.museum": true,
            "badajoz.museum": true,
            "baghdad.museum": true,
            "bahn.museum": true,
            "bale.museum": true,
            "baltimore.museum": true,
            "barcelona.museum": true,
            "baseball.museum": true,
            "basel.museum": true,
            "baths.museum": true,
            "bauern.museum": true,
            "beauxarts.museum": true,
            "beeldengeluid.museum": true,
            "bellevue.museum": true,
            "bergbau.museum": true,
            "berkeley.museum": true,
            "berlin.museum": true,
            "bern.museum": true,
            "bible.museum": true,
            "bilbao.museum": true,
            "bill.museum": true,
            "birdart.museum": true,
            "birthplace.museum": true,
            "bonn.museum": true,
            "boston.museum": true,
            "botanical.museum": true,
            "botanicalgarden.museum": true,
            "botanicgarden.museum": true,
            "botany.museum": true,
            "brandywinevalley.museum": true,
            "brasil.museum": true,
            "bristol.museum": true,
            "british.museum": true,
            "britishcolumbia.museum": true,
            "broadcast.museum": true,
            "brunel.museum": true,
            "brussel.museum": true,
            "brussels.museum": true,
            "bruxelles.museum": true,
            "building.museum": true,
            "burghof.museum": true,
            "bus.museum": true,
            "bushey.museum": true,
            "cadaques.museum": true,
            "california.museum": true,
            "cambridge.museum": true,
            "can.museum": true,
            "canada.museum": true,
            "capebreton.museum": true,
            "carrier.museum": true,
            "cartoonart.museum": true,
            "casadelamoneda.museum": true,
            "castle.museum": true,
            "castres.museum": true,
            "celtic.museum": true,
            "center.museum": true,
            "chattanooga.museum": true,
            "cheltenham.museum": true,
            "chesapeakebay.museum": true,
            "chicago.museum": true,
            "children.museum": true,
            "childrens.museum": true,
            "childrensgarden.museum": true,
            "chiropractic.museum": true,
            "chocolate.museum": true,
            "christiansburg.museum": true,
            "cincinnati.museum": true,
            "cinema.museum": true,
            "circus.museum": true,
            "civilisation.museum": true,
            "civilization.museum": true,
            "civilwar.museum": true,
            "clinton.museum": true,
            "clock.museum": true,
            "coal.museum": true,
            "coastaldefence.museum": true,
            "cody.museum": true,
            "coldwar.museum": true,
            "collection.museum": true,
            "colonialwilliamsburg.museum": true,
            "coloradoplateau.museum": true,
            "columbia.museum": true,
            "columbus.museum": true,
            "communication.museum": true,
            "communications.museum": true,
            "community.museum": true,
            "computer.museum": true,
            "computerhistory.museum": true,
            "xn--comunicaes-v6a2o.museum": true,
            "contemporary.museum": true,
            "contemporaryart.museum": true,
            "convent.museum": true,
            "copenhagen.museum": true,
            "corporation.museum": true,
            "xn--correios-e-telecomunicaes-ghc29a.museum": true,
            "corvette.museum": true,
            "costume.museum": true,
            "countryestate.museum": true,
            "county.museum": true,
            "crafts.museum": true,
            "cranbrook.museum": true,
            "creation.museum": true,
            "cultural.museum": true,
            "culturalcenter.museum": true,
            "culture.museum": true,
            "cyber.museum": true,
            "cymru.museum": true,
            "dali.museum": true,
            "dallas.museum": true,
            "database.museum": true,
            "ddr.museum": true,
            "decorativearts.museum": true,
            "delaware.museum": true,
            "delmenhorst.museum": true,
            "denmark.museum": true,
            "depot.museum": true,
            "design.museum": true,
            "detroit.museum": true,
            "dinosaur.museum": true,
            "discovery.museum": true,
            "dolls.museum": true,
            "donostia.museum": true,
            "durham.museum": true,
            "eastafrica.museum": true,
            "eastcoast.museum": true,
            "education.museum": true,
            "educational.museum": true,
            "egyptian.museum": true,
            "eisenbahn.museum": true,
            "elburg.museum": true,
            "elvendrell.museum": true,
            "embroidery.museum": true,
            "encyclopedic.museum": true,
            "england.museum": true,
            "entomology.museum": true,
            "environment.museum": true,
            "environmentalconservation.museum": true,
            "epilepsy.museum": true,
            "essex.museum": true,
            "estate.museum": true,
            "ethnology.museum": true,
            "exeter.museum": true,
            "exhibition.museum": true,
            "family.museum": true,
            "farm.museum": true,
            "farmequipment.museum": true,
            "farmers.museum": true,
            "farmstead.museum": true,
            "field.museum": true,
            "figueres.museum": true,
            "filatelia.museum": true,
            "film.museum": true,
            "fineart.museum": true,
            "finearts.museum": true,
            "finland.museum": true,
            "flanders.museum": true,
            "florida.museum": true,
            "force.museum": true,
            "fortmissoula.museum": true,
            "fortworth.museum": true,
            "foundation.museum": true,
            "francaise.museum": true,
            "frankfurt.museum": true,
            "franziskaner.museum": true,
            "freemasonry.museum": true,
            "freiburg.museum": true,
            "fribourg.museum": true,
            "frog.museum": true,
            "fundacio.museum": true,
            "furniture.museum": true,
            "gallery.museum": true,
            "garden.museum": true,
            "gateway.museum": true,
            "geelvinck.museum": true,
            "gemological.museum": true,
            "geology.museum": true,
            "georgia.museum": true,
            "giessen.museum": true,
            "glas.museum": true,
            "glass.museum": true,
            "gorge.museum": true,
            "grandrapids.museum": true,
            "graz.museum": true,
            "guernsey.museum": true,
            "halloffame.museum": true,
            "hamburg.museum": true,
            "handson.museum": true,
            "harvestcelebration.museum": true,
            "hawaii.museum": true,
            "health.museum": true,
            "heimatunduhren.museum": true,
            "hellas.museum": true,
            "helsinki.museum": true,
            "hembygdsforbund.museum": true,
            "heritage.museum": true,
            "histoire.museum": true,
            "historical.museum": true,
            "historicalsociety.museum": true,
            "historichouses.museum": true,
            "historisch.museum": true,
            "historisches.museum": true,
            "history.museum": true,
            "historyofscience.museum": true,
            "horology.museum": true,
            "house.museum": true,
            "humanities.museum": true,
            "illustration.museum": true,
            "imageandsound.museum": true,
            "indian.museum": true,
            "indiana.museum": true,
            "indianapolis.museum": true,
            "indianmarket.museum": true,
            "intelligence.museum": true,
            "interactive.museum": true,
            "iraq.museum": true,
            "iron.museum": true,
            "isleofman.museum": true,
            "jamison.museum": true,
            "jefferson.museum": true,
            "jerusalem.museum": true,
            "jewelry.museum": true,
            "jewish.museum": true,
            "jewishart.museum": true,
            "jfk.museum": true,
            "journalism.museum": true,
            "judaica.museum": true,
            "judygarland.museum": true,
            "juedisches.museum": true,
            "juif.museum": true,
            "karate.museum": true,
            "karikatur.museum": true,
            "kids.museum": true,
            "koebenhavn.museum": true,
            "koeln.museum": true,
            "kunst.museum": true,
            "kunstsammlung.museum": true,
            "kunstunddesign.museum": true,
            "labor.museum": true,
            "labour.museum": true,
            "lajolla.museum": true,
            "lancashire.museum": true,
            "landes.museum": true,
            "lans.museum": true,
            "xn--lns-qla.museum": true,
            "larsson.museum": true,
            "lewismiller.museum": true,
            "lincoln.museum": true,
            "linz.museum": true,
            "living.museum": true,
            "livinghistory.museum": true,
            "localhistory.museum": true,
            "london.museum": true,
            "losangeles.museum": true,
            "louvre.museum": true,
            "loyalist.museum": true,
            "lucerne.museum": true,
            "luxembourg.museum": true,
            "luzern.museum": true,
            "mad.museum": true,
            "madrid.museum": true,
            "mallorca.museum": true,
            "manchester.museum": true,
            "mansion.museum": true,
            "mansions.museum": true,
            "manx.museum": true,
            "marburg.museum": true,
            "maritime.museum": true,
            "maritimo.museum": true,
            "maryland.museum": true,
            "marylhurst.museum": true,
            "media.museum": true,
            "medical.museum": true,
            "medizinhistorisches.museum": true,
            "meeres.museum": true,
            "memorial.museum": true,
            "mesaverde.museum": true,
            "michigan.museum": true,
            "midatlantic.museum": true,
            "military.museum": true,
            "mill.museum": true,
            "miners.museum": true,
            "mining.museum": true,
            "minnesota.museum": true,
            "missile.museum": true,
            "missoula.museum": true,
            "modern.museum": true,
            "moma.museum": true,
            "money.museum": true,
            "monmouth.museum": true,
            "monticello.museum": true,
            "montreal.museum": true,
            "moscow.museum": true,
            "motorcycle.museum": true,
            "muenchen.museum": true,
            "muenster.museum": true,
            "mulhouse.museum": true,
            "muncie.museum": true,
            "museet.museum": true,
            "museumcenter.museum": true,
            "museumvereniging.museum": true,
            "music.museum": true,
            "national.museum": true,
            "nationalfirearms.museum": true,
            "nationalheritage.museum": true,
            "nativeamerican.museum": true,
            "naturalhistory.museum": true,
            "naturalhistorymuseum.museum": true,
            "naturalsciences.museum": true,
            "nature.museum": true,
            "naturhistorisches.museum": true,
            "natuurwetenschappen.museum": true,
            "naumburg.museum": true,
            "naval.museum": true,
            "nebraska.museum": true,
            "neues.museum": true,
            "newhampshire.museum": true,
            "newjersey.museum": true,
            "newmexico.museum": true,
            "newport.museum": true,
            "newspaper.museum": true,
            "newyork.museum": true,
            "niepce.museum": true,
            "norfolk.museum": true,
            "north.museum": true,
            "nrw.museum": true,
            "nuernberg.museum": true,
            "nuremberg.museum": true,
            "nyc.museum": true,
            "nyny.museum": true,
            "oceanographic.museum": true,
            "oceanographique.museum": true,
            "omaha.museum": true,
            "online.museum": true,
            "ontario.museum": true,
            "openair.museum": true,
            "oregon.museum": true,
            "oregontrail.museum": true,
            "otago.museum": true,
            "oxford.museum": true,
            "pacific.museum": true,
            "paderborn.museum": true,
            "palace.museum": true,
            "paleo.museum": true,
            "palmsprings.museum": true,
            "panama.museum": true,
            "paris.museum": true,
            "pasadena.museum": true,
            "pharmacy.museum": true,
            "philadelphia.museum": true,
            "philadelphiaarea.museum": true,
            "philately.museum": true,
            "phoenix.museum": true,
            "photography.museum": true,
            "pilots.museum": true,
            "pittsburgh.museum": true,
            "planetarium.museum": true,
            "plantation.museum": true,
            "plants.museum": true,
            "plaza.museum": true,
            "portal.museum": true,
            "portland.museum": true,
            "portlligat.museum": true,
            "posts-and-telecommunications.museum": true,
            "preservation.museum": true,
            "presidio.museum": true,
            "press.museum": true,
            "project.museum": true,
            "public.museum": true,
            "pubol.museum": true,
            "quebec.museum": true,
            "railroad.museum": true,
            "railway.museum": true,
            "research.museum": true,
            "resistance.museum": true,
            "riodejaneiro.museum": true,
            "rochester.museum": true,
            "rockart.museum": true,
            "roma.museum": true,
            "russia.museum": true,
            "saintlouis.museum": true,
            "salem.museum": true,
            "salvadordali.museum": true,
            "salzburg.museum": true,
            "sandiego.museum": true,
            "sanfrancisco.museum": true,
            "santabarbara.museum": true,
            "santacruz.museum": true,
            "santafe.museum": true,
            "saskatchewan.museum": true,
            "satx.museum": true,
            "savannahga.museum": true,
            "schlesisches.museum": true,
            "schoenbrunn.museum": true,
            "schokoladen.museum": true,
            "school.museum": true,
            "schweiz.museum": true,
            "science.museum": true,
            "scienceandhistory.museum": true,
            "scienceandindustry.museum": true,
            "sciencecenter.museum": true,
            "sciencecenters.museum": true,
            "science-fiction.museum": true,
            "sciencehistory.museum": true,
            "sciences.museum": true,
            "sciencesnaturelles.museum": true,
            "scotland.museum": true,
            "seaport.museum": true,
            "settlement.museum": true,
            "settlers.museum": true,
            "shell.museum": true,
            "sherbrooke.museum": true,
            "sibenik.museum": true,
            "silk.museum": true,
            "ski.museum": true,
            "skole.museum": true,
            "society.museum": true,
            "sologne.museum": true,
            "soundandvision.museum": true,
            "southcarolina.museum": true,
            "southwest.museum": true,
            "space.museum": true,
            "spy.museum": true,
            "square.museum": true,
            "stadt.museum": true,
            "stalbans.museum": true,
            "starnberg.museum": true,
            "state.museum": true,
            "stateofdelaware.museum": true,
            "station.museum": true,
            "steam.museum": true,
            "steiermark.museum": true,
            "stjohn.museum": true,
            "stockholm.museum": true,
            "stpetersburg.museum": true,
            "stuttgart.museum": true,
            "suisse.museum": true,
            "surgeonshall.museum": true,
            "surrey.museum": true,
            "svizzera.museum": true,
            "sweden.museum": true,
            "sydney.museum": true,
            "tank.museum": true,
            "tcm.museum": true,
            "technology.museum": true,
            "telekommunikation.museum": true,
            "television.museum": true,
            "texas.museum": true,
            "textile.museum": true,
            "theater.museum": true,
            "time.museum": true,
            "timekeeping.museum": true,
            "topology.museum": true,
            "torino.museum": true,
            "touch.museum": true,
            "town.museum": true,
            "transport.museum": true,
            "tree.museum": true,
            "trolley.museum": true,
            "trust.museum": true,
            "trustee.museum": true,
            "uhren.museum": true,
            "ulm.museum": true,
            "undersea.museum": true,
            "university.museum": true,
            "usa.museum": true,
            "usantiques.museum": true,
            "usarts.museum": true,
            "uscountryestate.museum": true,
            "usculture.museum": true,
            "usdecorativearts.museum": true,
            "usgarden.museum": true,
            "ushistory.museum": true,
            "ushuaia.museum": true,
            "uslivinghistory.museum": true,
            "utah.museum": true,
            "uvic.museum": true,
            "valley.museum": true,
            "vantaa.museum": true,
            "versailles.museum": true,
            "viking.museum": true,
            "village.museum": true,
            "virginia.museum": true,
            "virtual.museum": true,
            "virtuel.museum": true,
            "vlaanderen.museum": true,
            "volkenkunde.museum": true,
            "wales.museum": true,
            "wallonie.museum": true,
            "war.museum": true,
            "washingtondc.museum": true,
            "watchandclock.museum": true,
            "watch-and-clock.museum": true,
            "western.museum": true,
            "westfalen.museum": true,
            "whaling.museum": true,
            "wildlife.museum": true,
            "williamsburg.museum": true,
            "windmill.museum": true,
            "workshop.museum": true,
            "york.museum": true,
            "yorkshire.museum": true,
            "yosemite.museum": true,
            "youth.museum": true,
            "zoological.museum": true,
            "zoology.museum": true,
            "xn--9dbhblg6di.museum": true,
            "xn--h1aegh.museum": true,
            "mv": true,
            "aero.mv": true,
            "biz.mv": true,
            "com.mv": true,
            "coop.mv": true,
            "edu.mv": true,
            "gov.mv": true,
            "info.mv": true,
            "int.mv": true,
            "mil.mv": true,
            "museum.mv": true,
            "name.mv": true,
            "net.mv": true,
            "org.mv": true,
            "pro.mv": true,
            "mw": true,
            "ac.mw": true,
            "biz.mw": true,
            "co.mw": true,
            "com.mw": true,
            "coop.mw": true,
            "edu.mw": true,
            "gov.mw": true,
            "int.mw": true,
            "museum.mw": true,
            "net.mw": true,
            "org.mw": true,
            "mx": true,
            "com.mx": true,
            "org.mx": true,
            "gob.mx": true,
            "edu.mx": true,
            "net.mx": true,
            "my": true,
            "com.my": true,
            "net.my": true,
            "org.my": true,
            "gov.my": true,
            "edu.my": true,
            "mil.my": true,
            "name.my": true,
            "*.mz": true,
            "na": true,
            "info.na": true,
            "pro.na": true,
            "name.na": true,
            "school.na": true,
            "or.na": true,
            "dr.na": true,
            "us.na": true,
            "mx.na": true,
            "ca.na": true,
            "in.na": true,
            "cc.na": true,
            "tv.na": true,
            "ws.na": true,
            "mobi.na": true,
            "co.na": true,
            "com.na": true,
            "org.na": true,
            "name": true,
            "nc": true,
            "asso.nc": true,
            "ne": true,
            "net": true,
            "nf": true,
            "com.nf": true,
            "net.nf": true,
            "per.nf": true,
            "rec.nf": true,
            "web.nf": true,
            "arts.nf": true,
            "firm.nf": true,
            "info.nf": true,
            "other.nf": true,
            "store.nf": true,
            "ac.ng": true,
            "com.ng": true,
            "edu.ng": true,
            "gov.ng": true,
            "net.ng": true,
            "org.ng": true,
            "*.ni": true,
            "nl": true,
            "bv.nl": true,
            "no": true,
            "fhs.no": true,
            "vgs.no": true,
            "fylkesbibl.no": true,
            "folkebibl.no": true,
            "museum.no": true,
            "idrett.no": true,
            "priv.no": true,
            "mil.no": true,
            "stat.no": true,
            "dep.no": true,
            "kommune.no": true,
            "herad.no": true,
            "aa.no": true,
            "ah.no": true,
            "bu.no": true,
            "fm.no": true,
            "hl.no": true,
            "hm.no": true,
            "jan-mayen.no": true,
            "mr.no": true,
            "nl.no": true,
            "nt.no": true,
            "of.no": true,
            "ol.no": true,
            "oslo.no": true,
            "rl.no": true,
            "sf.no": true,
            "st.no": true,
            "svalbard.no": true,
            "tm.no": true,
            "tr.no": true,
            "va.no": true,
            "vf.no": true,
            "gs.aa.no": true,
            "gs.ah.no": true,
            "gs.bu.no": true,
            "gs.fm.no": true,
            "gs.hl.no": true,
            "gs.hm.no": true,
            "gs.jan-mayen.no": true,
            "gs.mr.no": true,
            "gs.nl.no": true,
            "gs.nt.no": true,
            "gs.of.no": true,
            "gs.ol.no": true,
            "gs.oslo.no": true,
            "gs.rl.no": true,
            "gs.sf.no": true,
            "gs.st.no": true,
            "gs.svalbard.no": true,
            "gs.tm.no": true,
            "gs.tr.no": true,
            "gs.va.no": true,
            "gs.vf.no": true,
            "akrehamn.no": true,
            "xn--krehamn-dxa.no": true,
            "algard.no": true,
            "xn--lgrd-poac.no": true,
            "arna.no": true,
            "brumunddal.no": true,
            "bryne.no": true,
            "bronnoysund.no": true,
            "xn--brnnysund-m8ac.no": true,
            "drobak.no": true,
            "xn--drbak-wua.no": true,
            "egersund.no": true,
            "fetsund.no": true,
            "floro.no": true,
            "xn--flor-jra.no": true,
            "fredrikstad.no": true,
            "hokksund.no": true,
            "honefoss.no": true,
            "xn--hnefoss-q1a.no": true,
            "jessheim.no": true,
            "jorpeland.no": true,
            "xn--jrpeland-54a.no": true,
            "kirkenes.no": true,
            "kopervik.no": true,
            "krokstadelva.no": true,
            "langevag.no": true,
            "xn--langevg-jxa.no": true,
            "leirvik.no": true,
            "mjondalen.no": true,
            "xn--mjndalen-64a.no": true,
            "mo-i-rana.no": true,
            "mosjoen.no": true,
            "xn--mosjen-eya.no": true,
            "nesoddtangen.no": true,
            "orkanger.no": true,
            "osoyro.no": true,
            "xn--osyro-wua.no": true,
            "raholt.no": true,
            "xn--rholt-mra.no": true,
            "sandnessjoen.no": true,
            "xn--sandnessjen-ogb.no": true,
            "skedsmokorset.no": true,
            "slattum.no": true,
            "spjelkavik.no": true,
            "stathelle.no": true,
            "stavern.no": true,
            "stjordalshalsen.no": true,
            "xn--stjrdalshalsen-sqb.no": true,
            "tananger.no": true,
            "tranby.no": true,
            "vossevangen.no": true,
            "afjord.no": true,
            "xn--fjord-lra.no": true,
            "agdenes.no": true,
            "al.no": true,
            "xn--l-1fa.no": true,
            "alesund.no": true,
            "xn--lesund-hua.no": true,
            "alstahaug.no": true,
            "alta.no": true,
            "xn--lt-liac.no": true,
            "alaheadju.no": true,
            "xn--laheadju-7ya.no": true,
            "alvdal.no": true,
            "amli.no": true,
            "xn--mli-tla.no": true,
            "amot.no": true,
            "xn--mot-tla.no": true,
            "andebu.no": true,
            "andoy.no": true,
            "xn--andy-ira.no": true,
            "andasuolo.no": true,
            "ardal.no": true,
            "xn--rdal-poa.no": true,
            "aremark.no": true,
            "arendal.no": true,
            "xn--s-1fa.no": true,
            "aseral.no": true,
            "xn--seral-lra.no": true,
            "asker.no": true,
            "askim.no": true,
            "askvoll.no": true,
            "askoy.no": true,
            "xn--asky-ira.no": true,
            "asnes.no": true,
            "xn--snes-poa.no": true,
            "audnedaln.no": true,
            "aukra.no": true,
            "aure.no": true,
            "aurland.no": true,
            "aurskog-holand.no": true,
            "xn--aurskog-hland-jnb.no": true,
            "austevoll.no": true,
            "austrheim.no": true,
            "averoy.no": true,
            "xn--avery-yua.no": true,
            "balestrand.no": true,
            "ballangen.no": true,
            "balat.no": true,
            "xn--blt-elab.no": true,
            "balsfjord.no": true,
            "bahccavuotna.no": true,
            "xn--bhccavuotna-k7a.no": true,
            "bamble.no": true,
            "bardu.no": true,
            "beardu.no": true,
            "beiarn.no": true,
            "bajddar.no": true,
            "xn--bjddar-pta.no": true,
            "baidar.no": true,
            "xn--bidr-5nac.no": true,
            "berg.no": true,
            "bergen.no": true,
            "berlevag.no": true,
            "xn--berlevg-jxa.no": true,
            "bearalvahki.no": true,
            "xn--bearalvhki-y4a.no": true,
            "bindal.no": true,
            "birkenes.no": true,
            "bjarkoy.no": true,
            "xn--bjarky-fya.no": true,
            "bjerkreim.no": true,
            "bjugn.no": true,
            "bodo.no": true,
            "xn--bod-2na.no": true,
            "badaddja.no": true,
            "xn--bdddj-mrabd.no": true,
            "budejju.no": true,
            "bokn.no": true,
            "bremanger.no": true,
            "bronnoy.no": true,
            "xn--brnny-wuac.no": true,
            "bygland.no": true,
            "bykle.no": true,
            "barum.no": true,
            "xn--brum-voa.no": true,
            "bo.telemark.no": true,
            "xn--b-5ga.telemark.no": true,
            "bo.nordland.no": true,
            "xn--b-5ga.nordland.no": true,
            "bievat.no": true,
            "xn--bievt-0qa.no": true,
            "bomlo.no": true,
            "xn--bmlo-gra.no": true,
            "batsfjord.no": true,
            "xn--btsfjord-9za.no": true,
            "bahcavuotna.no": true,
            "xn--bhcavuotna-s4a.no": true,
            "dovre.no": true,
            "drammen.no": true,
            "drangedal.no": true,
            "dyroy.no": true,
            "xn--dyry-ira.no": true,
            "donna.no": true,
            "xn--dnna-gra.no": true,
            "eid.no": true,
            "eidfjord.no": true,
            "eidsberg.no": true,
            "eidskog.no": true,
            "eidsvoll.no": true,
            "eigersund.no": true,
            "elverum.no": true,
            "enebakk.no": true,
            "engerdal.no": true,
            "etne.no": true,
            "etnedal.no": true,
            "evenes.no": true,
            "evenassi.no": true,
            "xn--eveni-0qa01ga.no": true,
            "evje-og-hornnes.no": true,
            "farsund.no": true,
            "fauske.no": true,
            "fuossko.no": true,
            "fuoisku.no": true,
            "fedje.no": true,
            "fet.no": true,
            "finnoy.no": true,
            "xn--finny-yua.no": true,
            "fitjar.no": true,
            "fjaler.no": true,
            "fjell.no": true,
            "flakstad.no": true,
            "flatanger.no": true,
            "flekkefjord.no": true,
            "flesberg.no": true,
            "flora.no": true,
            "fla.no": true,
            "xn--fl-zia.no": true,
            "folldal.no": true,
            "forsand.no": true,
            "fosnes.no": true,
            "frei.no": true,
            "frogn.no": true,
            "froland.no": true,
            "frosta.no": true,
            "frana.no": true,
            "xn--frna-woa.no": true,
            "froya.no": true,
            "xn--frya-hra.no": true,
            "fusa.no": true,
            "fyresdal.no": true,
            "forde.no": true,
            "xn--frde-gra.no": true,
            "gamvik.no": true,
            "gangaviika.no": true,
            "xn--ggaviika-8ya47h.no": true,
            "gaular.no": true,
            "gausdal.no": true,
            "gildeskal.no": true,
            "xn--gildeskl-g0a.no": true,
            "giske.no": true,
            "gjemnes.no": true,
            "gjerdrum.no": true,
            "gjerstad.no": true,
            "gjesdal.no": true,
            "gjovik.no": true,
            "xn--gjvik-wua.no": true,
            "gloppen.no": true,
            "gol.no": true,
            "gran.no": true,
            "grane.no": true,
            "granvin.no": true,
            "gratangen.no": true,
            "grimstad.no": true,
            "grong.no": true,
            "kraanghke.no": true,
            "xn--kranghke-b0a.no": true,
            "grue.no": true,
            "gulen.no": true,
            "hadsel.no": true,
            "halden.no": true,
            "halsa.no": true,
            "hamar.no": true,
            "hamaroy.no": true,
            "habmer.no": true,
            "xn--hbmer-xqa.no": true,
            "hapmir.no": true,
            "xn--hpmir-xqa.no": true,
            "hammerfest.no": true,
            "hammarfeasta.no": true,
            "xn--hmmrfeasta-s4ac.no": true,
            "haram.no": true,
            "hareid.no": true,
            "harstad.no": true,
            "hasvik.no": true,
            "aknoluokta.no": true,
            "xn--koluokta-7ya57h.no": true,
            "hattfjelldal.no": true,
            "aarborte.no": true,
            "haugesund.no": true,
            "hemne.no": true,
            "hemnes.no": true,
            "hemsedal.no": true,
            "heroy.more-og-romsdal.no": true,
            "xn--hery-ira.xn--mre-og-romsdal-qqb.no": true,
            "heroy.nordland.no": true,
            "xn--hery-ira.nordland.no": true,
            "hitra.no": true,
            "hjartdal.no": true,
            "hjelmeland.no": true,
            "hobol.no": true,
            "xn--hobl-ira.no": true,
            "hof.no": true,
            "hol.no": true,
            "hole.no": true,
            "holmestrand.no": true,
            "holtalen.no": true,
            "xn--holtlen-hxa.no": true,
            "hornindal.no": true,
            "horten.no": true,
            "hurdal.no": true,
            "hurum.no": true,
            "hvaler.no": true,
            "hyllestad.no": true,
            "hagebostad.no": true,
            "xn--hgebostad-g3a.no": true,
            "hoyanger.no": true,
            "xn--hyanger-q1a.no": true,
            "hoylandet.no": true,
            "xn--hylandet-54a.no": true,
            "ha.no": true,
            "xn--h-2fa.no": true,
            "ibestad.no": true,
            "inderoy.no": true,
            "xn--indery-fya.no": true,
            "iveland.no": true,
            "jevnaker.no": true,
            "jondal.no": true,
            "jolster.no": true,
            "xn--jlster-bya.no": true,
            "karasjok.no": true,
            "karasjohka.no": true,
            "xn--krjohka-hwab49j.no": true,
            "karlsoy.no": true,
            "galsa.no": true,
            "xn--gls-elac.no": true,
            "karmoy.no": true,
            "xn--karmy-yua.no": true,
            "kautokeino.no": true,
            "guovdageaidnu.no": true,
            "klepp.no": true,
            "klabu.no": true,
            "xn--klbu-woa.no": true,
            "kongsberg.no": true,
            "kongsvinger.no": true,
            "kragero.no": true,
            "xn--krager-gya.no": true,
            "kristiansand.no": true,
            "kristiansund.no": true,
            "krodsherad.no": true,
            "xn--krdsherad-m8a.no": true,
            "kvalsund.no": true,
            "rahkkeravju.no": true,
            "xn--rhkkervju-01af.no": true,
            "kvam.no": true,
            "kvinesdal.no": true,
            "kvinnherad.no": true,
            "kviteseid.no": true,
            "kvitsoy.no": true,
            "xn--kvitsy-fya.no": true,
            "kvafjord.no": true,
            "xn--kvfjord-nxa.no": true,
            "giehtavuoatna.no": true,
            "kvanangen.no": true,
            "xn--kvnangen-k0a.no": true,
            "navuotna.no": true,
            "xn--nvuotna-hwa.no": true,
            "kafjord.no": true,
            "xn--kfjord-iua.no": true,
            "gaivuotna.no": true,
            "xn--givuotna-8ya.no": true,
            "larvik.no": true,
            "lavangen.no": true,
            "lavagis.no": true,
            "loabat.no": true,
            "xn--loabt-0qa.no": true,
            "lebesby.no": true,
            "davvesiida.no": true,
            "leikanger.no": true,
            "leirfjord.no": true,
            "leka.no": true,
            "leksvik.no": true,
            "lenvik.no": true,
            "leangaviika.no": true,
            "xn--leagaviika-52b.no": true,
            "lesja.no": true,
            "levanger.no": true,
            "lier.no": true,
            "lierne.no": true,
            "lillehammer.no": true,
            "lillesand.no": true,
            "lindesnes.no": true,
            "lindas.no": true,
            "xn--linds-pra.no": true,
            "lom.no": true,
            "loppa.no": true,
            "lahppi.no": true,
            "xn--lhppi-xqa.no": true,
            "lund.no": true,
            "lunner.no": true,
            "luroy.no": true,
            "xn--lury-ira.no": true,
            "luster.no": true,
            "lyngdal.no": true,
            "lyngen.no": true,
            "ivgu.no": true,
            "lardal.no": true,
            "lerdal.no": true,
            "xn--lrdal-sra.no": true,
            "lodingen.no": true,
            "xn--ldingen-q1a.no": true,
            "lorenskog.no": true,
            "xn--lrenskog-54a.no": true,
            "loten.no": true,
            "xn--lten-gra.no": true,
            "malvik.no": true,
            "masoy.no": true,
            "xn--msy-ula0h.no": true,
            "muosat.no": true,
            "xn--muost-0qa.no": true,
            "mandal.no": true,
            "marker.no": true,
            "marnardal.no": true,
            "masfjorden.no": true,
            "meland.no": true,
            "meldal.no": true,
            "melhus.no": true,
            "meloy.no": true,
            "xn--mely-ira.no": true,
            "meraker.no": true,
            "xn--merker-kua.no": true,
            "moareke.no": true,
            "xn--moreke-jua.no": true,
            "midsund.no": true,
            "midtre-gauldal.no": true,
            "modalen.no": true,
            "modum.no": true,
            "molde.no": true,
            "moskenes.no": true,
            "moss.no": true,
            "mosvik.no": true,
            "malselv.no": true,
            "xn--mlselv-iua.no": true,
            "malatvuopmi.no": true,
            "xn--mlatvuopmi-s4a.no": true,
            "namdalseid.no": true,
            "aejrie.no": true,
            "namsos.no": true,
            "namsskogan.no": true,
            "naamesjevuemie.no": true,
            "xn--nmesjevuemie-tcba.no": true,
            "laakesvuemie.no": true,
            "nannestad.no": true,
            "narvik.no": true,
            "narviika.no": true,
            "naustdal.no": true,
            "nedre-eiker.no": true,
            "nes.akershus.no": true,
            "nes.buskerud.no": true,
            "nesna.no": true,
            "nesodden.no": true,
            "nesseby.no": true,
            "unjarga.no": true,
            "xn--unjrga-rta.no": true,
            "nesset.no": true,
            "nissedal.no": true,
            "nittedal.no": true,
            "nord-aurdal.no": true,
            "nord-fron.no": true,
            "nord-odal.no": true,
            "norddal.no": true,
            "nordkapp.no": true,
            "davvenjarga.no": true,
            "xn--davvenjrga-y4a.no": true,
            "nordre-land.no": true,
            "nordreisa.no": true,
            "raisa.no": true,
            "xn--risa-5na.no": true,
            "nore-og-uvdal.no": true,
            "notodden.no": true,
            "naroy.no": true,
            "xn--nry-yla5g.no": true,
            "notteroy.no": true,
            "xn--nttery-byae.no": true,
            "odda.no": true,
            "oksnes.no": true,
            "xn--ksnes-uua.no": true,
            "oppdal.no": true,
            "oppegard.no": true,
            "xn--oppegrd-ixa.no": true,
            "orkdal.no": true,
            "orland.no": true,
            "xn--rland-uua.no": true,
            "orskog.no": true,
            "xn--rskog-uua.no": true,
            "orsta.no": true,
            "xn--rsta-fra.no": true,
            "os.hedmark.no": true,
            "os.hordaland.no": true,
            "osen.no": true,
            "osteroy.no": true,
            "xn--ostery-fya.no": true,
            "ostre-toten.no": true,
            "xn--stre-toten-zcb.no": true,
            "overhalla.no": true,
            "ovre-eiker.no": true,
            "xn--vre-eiker-k8a.no": true,
            "oyer.no": true,
            "xn--yer-zna.no": true,
            "oygarden.no": true,
            "xn--ygarden-p1a.no": true,
            "oystre-slidre.no": true,
            "xn--ystre-slidre-ujb.no": true,
            "porsanger.no": true,
            "porsangu.no": true,
            "xn--porsgu-sta26f.no": true,
            "porsgrunn.no": true,
            "radoy.no": true,
            "xn--rady-ira.no": true,
            "rakkestad.no": true,
            "rana.no": true,
            "ruovat.no": true,
            "randaberg.no": true,
            "rauma.no": true,
            "rendalen.no": true,
            "rennebu.no": true,
            "rennesoy.no": true,
            "xn--rennesy-v1a.no": true,
            "rindal.no": true,
            "ringebu.no": true,
            "ringerike.no": true,
            "ringsaker.no": true,
            "rissa.no": true,
            "risor.no": true,
            "xn--risr-ira.no": true,
            "roan.no": true,
            "rollag.no": true,
            "rygge.no": true,
            "ralingen.no": true,
            "xn--rlingen-mxa.no": true,
            "rodoy.no": true,
            "xn--rdy-0nab.no": true,
            "romskog.no": true,
            "xn--rmskog-bya.no": true,
            "roros.no": true,
            "xn--rros-gra.no": true,
            "rost.no": true,
            "xn--rst-0na.no": true,
            "royken.no": true,
            "xn--ryken-vua.no": true,
            "royrvik.no": true,
            "xn--ryrvik-bya.no": true,
            "rade.no": true,
            "xn--rde-ula.no": true,
            "salangen.no": true,
            "siellak.no": true,
            "saltdal.no": true,
            "salat.no": true,
            "xn--slt-elab.no": true,
            "xn--slat-5na.no": true,
            "samnanger.no": true,
            "sande.more-og-romsdal.no": true,
            "sande.xn--mre-og-romsdal-qqb.no": true,
            "sande.vestfold.no": true,
            "sandefjord.no": true,
            "sandnes.no": true,
            "sandoy.no": true,
            "xn--sandy-yua.no": true,
            "sarpsborg.no": true,
            "sauda.no": true,
            "sauherad.no": true,
            "sel.no": true,
            "selbu.no": true,
            "selje.no": true,
            "seljord.no": true,
            "sigdal.no": true,
            "siljan.no": true,
            "sirdal.no": true,
            "skaun.no": true,
            "skedsmo.no": true,
            "ski.no": true,
            "skien.no": true,
            "skiptvet.no": true,
            "skjervoy.no": true,
            "xn--skjervy-v1a.no": true,
            "skierva.no": true,
            "xn--skierv-uta.no": true,
            "skjak.no": true,
            "xn--skjk-soa.no": true,
            "skodje.no": true,
            "skanland.no": true,
            "xn--sknland-fxa.no": true,
            "skanit.no": true,
            "xn--sknit-yqa.no": true,
            "smola.no": true,
            "xn--smla-hra.no": true,
            "snillfjord.no": true,
            "snasa.no": true,
            "xn--snsa-roa.no": true,
            "snoasa.no": true,
            "snaase.no": true,
            "xn--snase-nra.no": true,
            "sogndal.no": true,
            "sokndal.no": true,
            "sola.no": true,
            "solund.no": true,
            "songdalen.no": true,
            "sortland.no": true,
            "spydeberg.no": true,
            "stange.no": true,
            "stavanger.no": true,
            "steigen.no": true,
            "steinkjer.no": true,
            "stjordal.no": true,
            "xn--stjrdal-s1a.no": true,
            "stokke.no": true,
            "stor-elvdal.no": true,
            "stord.no": true,
            "stordal.no": true,
            "storfjord.no": true,
            "omasvuotna.no": true,
            "strand.no": true,
            "stranda.no": true,
            "stryn.no": true,
            "sula.no": true,
            "suldal.no": true,
            "sund.no": true,
            "sunndal.no": true,
            "surnadal.no": true,
            "sveio.no": true,
            "svelvik.no": true,
            "sykkylven.no": true,
            "sogne.no": true,
            "xn--sgne-gra.no": true,
            "somna.no": true,
            "xn--smna-gra.no": true,
            "sondre-land.no": true,
            "xn--sndre-land-0cb.no": true,
            "sor-aurdal.no": true,
            "xn--sr-aurdal-l8a.no": true,
            "sor-fron.no": true,
            "xn--sr-fron-q1a.no": true,
            "sor-odal.no": true,
            "xn--sr-odal-q1a.no": true,
            "sor-varanger.no": true,
            "xn--sr-varanger-ggb.no": true,
            "matta-varjjat.no": true,
            "xn--mtta-vrjjat-k7af.no": true,
            "sorfold.no": true,
            "xn--srfold-bya.no": true,
            "sorreisa.no": true,
            "xn--srreisa-q1a.no": true,
            "sorum.no": true,
            "xn--srum-gra.no": true,
            "tana.no": true,
            "deatnu.no": true,
            "time.no": true,
            "tingvoll.no": true,
            "tinn.no": true,
            "tjeldsund.no": true,
            "dielddanuorri.no": true,
            "tjome.no": true,
            "xn--tjme-hra.no": true,
            "tokke.no": true,
            "tolga.no": true,
            "torsken.no": true,
            "tranoy.no": true,
            "xn--trany-yua.no": true,
            "tromso.no": true,
            "xn--troms-zua.no": true,
            "tromsa.no": true,
            "romsa.no": true,
            "trondheim.no": true,
            "troandin.no": true,
            "trysil.no": true,
            "trana.no": true,
            "xn--trna-woa.no": true,
            "trogstad.no": true,
            "xn--trgstad-r1a.no": true,
            "tvedestrand.no": true,
            "tydal.no": true,
            "tynset.no": true,
            "tysfjord.no": true,
            "divtasvuodna.no": true,
            "divttasvuotna.no": true,
            "tysnes.no": true,
            "tysvar.no": true,
            "xn--tysvr-vra.no": true,
            "tonsberg.no": true,
            "xn--tnsberg-q1a.no": true,
            "ullensaker.no": true,
            "ullensvang.no": true,
            "ulvik.no": true,
            "utsira.no": true,
            "vadso.no": true,
            "xn--vads-jra.no": true,
            "cahcesuolo.no": true,
            "xn--hcesuolo-7ya35b.no": true,
            "vaksdal.no": true,
            "valle.no": true,
            "vang.no": true,
            "vanylven.no": true,
            "vardo.no": true,
            "xn--vard-jra.no": true,
            "varggat.no": true,
            "xn--vrggt-xqad.no": true,
            "vefsn.no": true,
            "vaapste.no": true,
            "vega.no": true,
            "vegarshei.no": true,
            "xn--vegrshei-c0a.no": true,
            "vennesla.no": true,
            "verdal.no": true,
            "verran.no": true,
            "vestby.no": true,
            "vestnes.no": true,
            "vestre-slidre.no": true,
            "vestre-toten.no": true,
            "vestvagoy.no": true,
            "xn--vestvgy-ixa6o.no": true,
            "vevelstad.no": true,
            "vik.no": true,
            "vikna.no": true,
            "vindafjord.no": true,
            "volda.no": true,
            "voss.no": true,
            "varoy.no": true,
            "xn--vry-yla5g.no": true,
            "vagan.no": true,
            "xn--vgan-qoa.no": true,
            "voagat.no": true,
            "vagsoy.no": true,
            "xn--vgsy-qoa0j.no": true,
            "vaga.no": true,
            "xn--vg-yiab.no": true,
            "valer.ostfold.no": true,
            "xn--vler-qoa.xn--stfold-9xa.no": true,
            "valer.hedmark.no": true,
            "xn--vler-qoa.hedmark.no": true,
            "*.np": true,
            "nr": true,
            "biz.nr": true,
            "info.nr": true,
            "gov.nr": true,
            "edu.nr": true,
            "org.nr": true,
            "net.nr": true,
            "com.nr": true,
            "nu": true,
            "*.nz": true,
            "*.om": true,
            "mediaphone.om": false,
            "nawrastelecom.om": false,
            "nawras.om": false,
            "omanmobile.om": false,
            "omanpost.om": false,
            "omantel.om": false,
            "rakpetroleum.om": false,
            "siemens.om": false,
            "songfest.om": false,
            "statecouncil.om": false,
            "org": true,
            "pa": true,
            "ac.pa": true,
            "gob.pa": true,
            "com.pa": true,
            "org.pa": true,
            "sld.pa": true,
            "edu.pa": true,
            "net.pa": true,
            "ing.pa": true,
            "abo.pa": true,
            "med.pa": true,
            "nom.pa": true,
            "pe": true,
            "edu.pe": true,
            "gob.pe": true,
            "nom.pe": true,
            "mil.pe": true,
            "org.pe": true,
            "com.pe": true,
            "net.pe": true,
            "pf": true,
            "com.pf": true,
            "org.pf": true,
            "edu.pf": true,
            "*.pg": true,
            "ph": true,
            "com.ph": true,
            "net.ph": true,
            "org.ph": true,
            "gov.ph": true,
            "edu.ph": true,
            "ngo.ph": true,
            "mil.ph": true,
            "i.ph": true,
            "pk": true,
            "com.pk": true,
            "net.pk": true,
            "edu.pk": true,
            "org.pk": true,
            "fam.pk": true,
            "biz.pk": true,
            "web.pk": true,
            "gov.pk": true,
            "gob.pk": true,
            "gok.pk": true,
            "gon.pk": true,
            "gop.pk": true,
            "gos.pk": true,
            "info.pk": true,
            "pl": true,
            "aid.pl": true,
            "agro.pl": true,
            "atm.pl": true,
            "auto.pl": true,
            "biz.pl": true,
            "com.pl": true,
            "edu.pl": true,
            "gmina.pl": true,
            "gsm.pl": true,
            "info.pl": true,
            "mail.pl": true,
            "miasta.pl": true,
            "media.pl": true,
            "mil.pl": true,
            "net.pl": true,
            "nieruchomosci.pl": true,
            "nom.pl": true,
            "org.pl": true,
            "pc.pl": true,
            "powiat.pl": true,
            "priv.pl": true,
            "realestate.pl": true,
            "rel.pl": true,
            "sex.pl": true,
            "shop.pl": true,
            "sklep.pl": true,
            "sos.pl": true,
            "szkola.pl": true,
            "targi.pl": true,
            "tm.pl": true,
            "tourism.pl": true,
            "travel.pl": true,
            "turystyka.pl": true,
            "6bone.pl": true,
            "art.pl": true,
            "mbone.pl": true,
            "gov.pl": true,
            "uw.gov.pl": true,
            "um.gov.pl": true,
            "ug.gov.pl": true,
            "upow.gov.pl": true,
            "starostwo.gov.pl": true,
            "so.gov.pl": true,
            "sr.gov.pl": true,
            "po.gov.pl": true,
            "pa.gov.pl": true,
            "ngo.pl": true,
            "irc.pl": true,
            "usenet.pl": true,
            "augustow.pl": true,
            "babia-gora.pl": true,
            "bedzin.pl": true,
            "beskidy.pl": true,
            "bialowieza.pl": true,
            "bialystok.pl": true,
            "bielawa.pl": true,
            "bieszczady.pl": true,
            "boleslawiec.pl": true,
            "bydgoszcz.pl": true,
            "bytom.pl": true,
            "cieszyn.pl": true,
            "czeladz.pl": true,
            "czest.pl": true,
            "dlugoleka.pl": true,
            "elblag.pl": true,
            "elk.pl": true,
            "glogow.pl": true,
            "gniezno.pl": true,
            "gorlice.pl": true,
            "grajewo.pl": true,
            "ilawa.pl": true,
            "jaworzno.pl": true,
            "jelenia-gora.pl": true,
            "jgora.pl": true,
            "kalisz.pl": true,
            "kazimierz-dolny.pl": true,
            "karpacz.pl": true,
            "kartuzy.pl": true,
            "kaszuby.pl": true,
            "katowice.pl": true,
            "kepno.pl": true,
            "ketrzyn.pl": true,
            "klodzko.pl": true,
            "kobierzyce.pl": true,
            "kolobrzeg.pl": true,
            "konin.pl": true,
            "konskowola.pl": true,
            "kutno.pl": true,
            "lapy.pl": true,
            "lebork.pl": true,
            "legnica.pl": true,
            "lezajsk.pl": true,
            "limanowa.pl": true,
            "lomza.pl": true,
            "lowicz.pl": true,
            "lubin.pl": true,
            "lukow.pl": true,
            "malbork.pl": true,
            "malopolska.pl": true,
            "mazowsze.pl": true,
            "mazury.pl": true,
            "mielec.pl": true,
            "mielno.pl": true,
            "mragowo.pl": true,
            "naklo.pl": true,
            "nowaruda.pl": true,
            "nysa.pl": true,
            "olawa.pl": true,
            "olecko.pl": true,
            "olkusz.pl": true,
            "olsztyn.pl": true,
            "opoczno.pl": true,
            "opole.pl": true,
            "ostroda.pl": true,
            "ostroleka.pl": true,
            "ostrowiec.pl": true,
            "ostrowwlkp.pl": true,
            "pila.pl": true,
            "pisz.pl": true,
            "podhale.pl": true,
            "podlasie.pl": true,
            "polkowice.pl": true,
            "pomorze.pl": true,
            "pomorskie.pl": true,
            "prochowice.pl": true,
            "pruszkow.pl": true,
            "przeworsk.pl": true,
            "pulawy.pl": true,
            "radom.pl": true,
            "rawa-maz.pl": true,
            "rybnik.pl": true,
            "rzeszow.pl": true,
            "sanok.pl": true,
            "sejny.pl": true,
            "siedlce.pl": true,
            "slask.pl": true,
            "slupsk.pl": true,
            "sosnowiec.pl": true,
            "stalowa-wola.pl": true,
            "skoczow.pl": true,
            "starachowice.pl": true,
            "stargard.pl": true,
            "suwalki.pl": true,
            "swidnica.pl": true,
            "swiebodzin.pl": true,
            "swinoujscie.pl": true,
            "szczecin.pl": true,
            "szczytno.pl": true,
            "tarnobrzeg.pl": true,
            "tgory.pl": true,
            "turek.pl": true,
            "tychy.pl": true,
            "ustka.pl": true,
            "walbrzych.pl": true,
            "warmia.pl": true,
            "warszawa.pl": true,
            "waw.pl": true,
            "wegrow.pl": true,
            "wielun.pl": true,
            "wlocl.pl": true,
            "wloclawek.pl": true,
            "wodzislaw.pl": true,
            "wolomin.pl": true,
            "wroclaw.pl": true,
            "zachpomor.pl": true,
            "zagan.pl": true,
            "zarow.pl": true,
            "zgora.pl": true,
            "zgorzelec.pl": true,
            "gda.pl": true,
            "gdansk.pl": true,
            "gdynia.pl": true,
            "med.pl": true,
            "sopot.pl": true,
            "gliwice.pl": true,
            "krakow.pl": true,
            "poznan.pl": true,
            "wroc.pl": true,
            "zakopane.pl": true,
            "pm": true,
            "pn": true,
            "gov.pn": true,
            "co.pn": true,
            "org.pn": true,
            "edu.pn": true,
            "net.pn": true,
            "pr": true,
            "com.pr": true,
            "net.pr": true,
            "org.pr": true,
            "gov.pr": true,
            "edu.pr": true,
            "isla.pr": true,
            "pro.pr": true,
            "biz.pr": true,
            "info.pr": true,
            "name.pr": true,
            "est.pr": true,
            "prof.pr": true,
            "ac.pr": true,
            "pro": true,
            "aca.pro": true,
            "bar.pro": true,
            "cpa.pro": true,
            "jur.pro": true,
            "law.pro": true,
            "med.pro": true,
            "eng.pro": true,
            "ps": true,
            "edu.ps": true,
            "gov.ps": true,
            "sec.ps": true,
            "plo.ps": true,
            "com.ps": true,
            "org.ps": true,
            "net.ps": true,
            "pt": true,
            "net.pt": true,
            "gov.pt": true,
            "org.pt": true,
            "edu.pt": true,
            "int.pt": true,
            "publ.pt": true,
            "com.pt": true,
            "nome.pt": true,
            "pw": true,
            "co.pw": true,
            "ne.pw": true,
            "or.pw": true,
            "ed.pw": true,
            "go.pw": true,
            "belau.pw": true,
            "*.py": true,
            "qa": true,
            "com.qa": true,
            "edu.qa": true,
            "gov.qa": true,
            "mil.qa": true,
            "name.qa": true,
            "net.qa": true,
            "org.qa": true,
            "sch.qa": true,
            "re": true,
            "com.re": true,
            "asso.re": true,
            "nom.re": true,
            "ro": true,
            "com.ro": true,
            "org.ro": true,
            "tm.ro": true,
            "nt.ro": true,
            "nom.ro": true,
            "info.ro": true,
            "rec.ro": true,
            "arts.ro": true,
            "firm.ro": true,
            "store.ro": true,
            "www.ro": true,
            "rs": true,
            "co.rs": true,
            "org.rs": true,
            "edu.rs": true,
            "ac.rs": true,
            "gov.rs": true,
            "in.rs": true,
            "ru": true,
            "ac.ru": true,
            "com.ru": true,
            "edu.ru": true,
            "int.ru": true,
            "net.ru": true,
            "org.ru": true,
            "pp.ru": true,
            "adygeya.ru": true,
            "altai.ru": true,
            "amur.ru": true,
            "arkhangelsk.ru": true,
            "astrakhan.ru": true,
            "bashkiria.ru": true,
            "belgorod.ru": true,
            "bir.ru": true,
            "bryansk.ru": true,
            "buryatia.ru": true,
            "cbg.ru": true,
            "chel.ru": true,
            "chelyabinsk.ru": true,
            "chita.ru": true,
            "chukotka.ru": true,
            "chuvashia.ru": true,
            "dagestan.ru": true,
            "dudinka.ru": true,
            "e-burg.ru": true,
            "grozny.ru": true,
            "irkutsk.ru": true,
            "ivanovo.ru": true,
            "izhevsk.ru": true,
            "jar.ru": true,
            "joshkar-ola.ru": true,
            "kalmykia.ru": true,
            "kaluga.ru": true,
            "kamchatka.ru": true,
            "karelia.ru": true,
            "kazan.ru": true,
            "kchr.ru": true,
            "kemerovo.ru": true,
            "khabarovsk.ru": true,
            "khakassia.ru": true,
            "khv.ru": true,
            "kirov.ru": true,
            "koenig.ru": true,
            "komi.ru": true,
            "kostroma.ru": true,
            "krasnoyarsk.ru": true,
            "kuban.ru": true,
            "kurgan.ru": true,
            "kursk.ru": true,
            "lipetsk.ru": true,
            "magadan.ru": true,
            "mari.ru": true,
            "mari-el.ru": true,
            "marine.ru": true,
            "mordovia.ru": true,
            "mosreg.ru": true,
            "msk.ru": true,
            "murmansk.ru": true,
            "nalchik.ru": true,
            "nnov.ru": true,
            "nov.ru": true,
            "novosibirsk.ru": true,
            "nsk.ru": true,
            "omsk.ru": true,
            "orenburg.ru": true,
            "oryol.ru": true,
            "palana.ru": true,
            "penza.ru": true,
            "perm.ru": true,
            "pskov.ru": true,
            "ptz.ru": true,
            "rnd.ru": true,
            "ryazan.ru": true,
            "sakhalin.ru": true,
            "samara.ru": true,
            "saratov.ru": true,
            "simbirsk.ru": true,
            "smolensk.ru": true,
            "spb.ru": true,
            "stavropol.ru": true,
            "stv.ru": true,
            "surgut.ru": true,
            "tambov.ru": true,
            "tatarstan.ru": true,
            "tom.ru": true,
            "tomsk.ru": true,
            "tsaritsyn.ru": true,
            "tsk.ru": true,
            "tula.ru": true,
            "tuva.ru": true,
            "tver.ru": true,
            "tyumen.ru": true,
            "udm.ru": true,
            "udmurtia.ru": true,
            "ulan-ude.ru": true,
            "vladikavkaz.ru": true,
            "vladimir.ru": true,
            "vladivostok.ru": true,
            "volgograd.ru": true,
            "vologda.ru": true,
            "voronezh.ru": true,
            "vrn.ru": true,
            "vyatka.ru": true,
            "yakutia.ru": true,
            "yamal.ru": true,
            "yaroslavl.ru": true,
            "yekaterinburg.ru": true,
            "yuzhno-sakhalinsk.ru": true,
            "amursk.ru": true,
            "baikal.ru": true,
            "cmw.ru": true,
            "fareast.ru": true,
            "jamal.ru": true,
            "kms.ru": true,
            "k-uralsk.ru": true,
            "kustanai.ru": true,
            "kuzbass.ru": true,
            "magnitka.ru": true,
            "mytis.ru": true,
            "nakhodka.ru": true,
            "nkz.ru": true,
            "norilsk.ru": true,
            "oskol.ru": true,
            "pyatigorsk.ru": true,
            "rubtsovsk.ru": true,
            "snz.ru": true,
            "syzran.ru": true,
            "vdonsk.ru": true,
            "zgrad.ru": true,
            "gov.ru": true,
            "mil.ru": true,
            "test.ru": true,
            "rw": true,
            "gov.rw": true,
            "net.rw": true,
            "edu.rw": true,
            "ac.rw": true,
            "com.rw": true,
            "co.rw": true,
            "int.rw": true,
            "mil.rw": true,
            "gouv.rw": true,
            "sa": true,
            "com.sa": true,
            "net.sa": true,
            "org.sa": true,
            "gov.sa": true,
            "med.sa": true,
            "pub.sa": true,
            "edu.sa": true,
            "sch.sa": true,
            "sb": true,
            "com.sb": true,
            "edu.sb": true,
            "gov.sb": true,
            "net.sb": true,
            "org.sb": true,
            "sc": true,
            "com.sc": true,
            "gov.sc": true,
            "net.sc": true,
            "org.sc": true,
            "edu.sc": true,
            "sd": true,
            "com.sd": true,
            "net.sd": true,
            "org.sd": true,
            "edu.sd": true,
            "med.sd": true,
            "gov.sd": true,
            "info.sd": true,
            "se": true,
            "a.se": true,
            "ac.se": true,
            "b.se": true,
            "bd.se": true,
            "brand.se": true,
            "c.se": true,
            "d.se": true,
            "e.se": true,
            "f.se": true,
            "fh.se": true,
            "fhsk.se": true,
            "fhv.se": true,
            "g.se": true,
            "h.se": true,
            "i.se": true,
            "k.se": true,
            "komforb.se": true,
            "kommunalforbund.se": true,
            "komvux.se": true,
            "l.se": true,
            "lanbib.se": true,
            "m.se": true,
            "n.se": true,
            "naturbruksgymn.se": true,
            "o.se": true,
            "org.se": true,
            "p.se": true,
            "parti.se": true,
            "pp.se": true,
            "press.se": true,
            "r.se": true,
            "s.se": true,
            "sshn.se": true,
            "t.se": true,
            "tm.se": true,
            "u.se": true,
            "w.se": true,
            "x.se": true,
            "y.se": true,
            "z.se": true,
            "sg": true,
            "com.sg": true,
            "net.sg": true,
            "org.sg": true,
            "gov.sg": true,
            "edu.sg": true,
            "per.sg": true,
            "sh": true,
            "si": true,
            "sk": true,
            "sl": true,
            "com.sl": true,
            "net.sl": true,
            "edu.sl": true,
            "gov.sl": true,
            "org.sl": true,
            "sm": true,
            "sn": true,
            "art.sn": true,
            "com.sn": true,
            "edu.sn": true,
            "gouv.sn": true,
            "org.sn": true,
            "perso.sn": true,
            "univ.sn": true,
            "so": true,
            "com.so": true,
            "net.so": true,
            "org.so": true,
            "sr": true,
            "st": true,
            "co.st": true,
            "com.st": true,
            "consulado.st": true,
            "edu.st": true,
            "embaixada.st": true,
            "gov.st": true,
            "mil.st": true,
            "net.st": true,
            "org.st": true,
            "principe.st": true,
            "saotome.st": true,
            "store.st": true,
            "su": true,
            "*.sv": true,
            "sy": true,
            "edu.sy": true,
            "gov.sy": true,
            "net.sy": true,
            "mil.sy": true,
            "com.sy": true,
            "org.sy": true,
            "sz": true,
            "co.sz": true,
            "ac.sz": true,
            "org.sz": true,
            "tc": true,
            "td": true,
            "tel": true,
            "tf": true,
            "tg": true,
            "th": true,
            "ac.th": true,
            "co.th": true,
            "go.th": true,
            "in.th": true,
            "mi.th": true,
            "net.th": true,
            "or.th": true,
            "tj": true,
            "ac.tj": true,
            "biz.tj": true,
            "co.tj": true,
            "com.tj": true,
            "edu.tj": true,
            "go.tj": true,
            "gov.tj": true,
            "int.tj": true,
            "mil.tj": true,
            "name.tj": true,
            "net.tj": true,
            "nic.tj": true,
            "org.tj": true,
            "test.tj": true,
            "web.tj": true,
            "tk": true,
            "tl": true,
            "gov.tl": true,
            "tm": true,
            "tn": true,
            "com.tn": true,
            "ens.tn": true,
            "fin.tn": true,
            "gov.tn": true,
            "ind.tn": true,
            "intl.tn": true,
            "nat.tn": true,
            "net.tn": true,
            "org.tn": true,
            "info.tn": true,
            "perso.tn": true,
            "tourism.tn": true,
            "edunet.tn": true,
            "rnrt.tn": true,
            "rns.tn": true,
            "rnu.tn": true,
            "mincom.tn": true,
            "agrinet.tn": true,
            "defense.tn": true,
            "turen.tn": true,
            "to": true,
            "com.to": true,
            "gov.to": true,
            "net.to": true,
            "org.to": true,
            "edu.to": true,
            "mil.to": true,
            "*.tr": true,
            "nic.tr": false,
            "gov.nc.tr": true,
            "travel": true,
            "tt": true,
            "co.tt": true,
            "com.tt": true,
            "org.tt": true,
            "net.tt": true,
            "biz.tt": true,
            "info.tt": true,
            "pro.tt": true,
            "int.tt": true,
            "coop.tt": true,
            "jobs.tt": true,
            "mobi.tt": true,
            "travel.tt": true,
            "museum.tt": true,
            "aero.tt": true,
            "name.tt": true,
            "gov.tt": true,
            "edu.tt": true,
            "tv": true,
            "tw": true,
            "edu.tw": true,
            "gov.tw": true,
            "mil.tw": true,
            "com.tw": true,
            "net.tw": true,
            "org.tw": true,
            "idv.tw": true,
            "game.tw": true,
            "ebiz.tw": true,
            "club.tw": true,
            "xn--zf0ao64a.tw": true,
            "xn--uc0atv.tw": true,
            "xn--czrw28b.tw": true,
            "ac.tz": true,
            "co.tz": true,
            "go.tz": true,
            "mil.tz": true,
            "ne.tz": true,
            "or.tz": true,
            "sc.tz": true,
            "ua": true,
            "com.ua": true,
            "edu.ua": true,
            "gov.ua": true,
            "in.ua": true,
            "net.ua": true,
            "org.ua": true,
            "cherkassy.ua": true,
            "chernigov.ua": true,
            "chernovtsy.ua": true,
            "ck.ua": true,
            "cn.ua": true,
            "crimea.ua": true,
            "cv.ua": true,
            "dn.ua": true,
            "dnepropetrovsk.ua": true,
            "donetsk.ua": true,
            "dp.ua": true,
            "if.ua": true,
            "ivano-frankivsk.ua": true,
            "kh.ua": true,
            "kharkov.ua": true,
            "kherson.ua": true,
            "khmelnitskiy.ua": true,
            "kiev.ua": true,
            "kirovograd.ua": true,
            "km.ua": true,
            "kr.ua": true,
            "ks.ua": true,
            "kv.ua": true,
            "lg.ua": true,
            "lugansk.ua": true,
            "lutsk.ua": true,
            "lviv.ua": true,
            "mk.ua": true,
            "nikolaev.ua": true,
            "od.ua": true,
            "odessa.ua": true,
            "pl.ua": true,
            "poltava.ua": true,
            "rovno.ua": true,
            "rv.ua": true,
            "sebastopol.ua": true,
            "sumy.ua": true,
            "te.ua": true,
            "ternopil.ua": true,
            "uzhgorod.ua": true,
            "vinnica.ua": true,
            "vn.ua": true,
            "zaporizhzhe.ua": true,
            "zp.ua": true,
            "zhitomir.ua": true,
            "zt.ua": true,
            "co.ua": true,
            "pp.ua": true,
            "ug": true,
            "co.ug": true,
            "ac.ug": true,
            "sc.ug": true,
            "go.ug": true,
            "ne.ug": true,
            "or.ug": true,
            "*.uk": true,
            "*.sch.uk": true,
            "bl.uk": false,
            "british-library.uk": false,
            "icnet.uk": false,
            "jet.uk": false,
            "mod.uk": false,
            "nel.uk": false,
            "nhs.uk": false,
            "nic.uk": false,
            "nls.uk": false,
            "national-library-scotland.uk": false,
            "parliament.uk": false,
            "police.uk": false,
            "us": true,
            "dni.us": true,
            "fed.us": true,
            "isa.us": true,
            "kids.us": true,
            "nsn.us": true,
            "ak.us": true,
            "al.us": true,
            "ar.us": true,
            "as.us": true,
            "az.us": true,
            "ca.us": true,
            "co.us": true,
            "ct.us": true,
            "dc.us": true,
            "de.us": true,
            "fl.us": true,
            "ga.us": true,
            "gu.us": true,
            "hi.us": true,
            "ia.us": true,
            "id.us": true,
            "il.us": true,
            "in.us": true,
            "ks.us": true,
            "ky.us": true,
            "la.us": true,
            "ma.us": true,
            "md.us": true,
            "me.us": true,
            "mi.us": true,
            "mn.us": true,
            "mo.us": true,
            "ms.us": true,
            "mt.us": true,
            "nc.us": true,
            "nd.us": true,
            "ne.us": true,
            "nh.us": true,
            "nj.us": true,
            "nm.us": true,
            "nv.us": true,
            "ny.us": true,
            "oh.us": true,
            "ok.us": true,
            "or.us": true,
            "pa.us": true,
            "pr.us": true,
            "ri.us": true,
            "sc.us": true,
            "sd.us": true,
            "tn.us": true,
            "tx.us": true,
            "ut.us": true,
            "vi.us": true,
            "vt.us": true,
            "va.us": true,
            "wa.us": true,
            "wi.us": true,
            "wv.us": true,
            "wy.us": true,
            "k12.ak.us": true,
            "k12.al.us": true,
            "k12.ar.us": true,
            "k12.as.us": true,
            "k12.az.us": true,
            "k12.ca.us": true,
            "k12.co.us": true,
            "k12.ct.us": true,
            "k12.dc.us": true,
            "k12.de.us": true,
            "k12.fl.us": true,
            "k12.ga.us": true,
            "k12.gu.us": true,
            "k12.ia.us": true,
            "k12.id.us": true,
            "k12.il.us": true,
            "k12.in.us": true,
            "k12.ks.us": true,
            "k12.ky.us": true,
            "k12.la.us": true,
            "k12.ma.us": true,
            "k12.md.us": true,
            "k12.me.us": true,
            "k12.mi.us": true,
            "k12.mn.us": true,
            "k12.mo.us": true,
            "k12.ms.us": true,
            "k12.mt.us": true,
            "k12.nc.us": true,
            "k12.nd.us": true,
            "k12.ne.us": true,
            "k12.nh.us": true,
            "k12.nj.us": true,
            "k12.nm.us": true,
            "k12.nv.us": true,
            "k12.ny.us": true,
            "k12.oh.us": true,
            "k12.ok.us": true,
            "k12.or.us": true,
            "k12.pa.us": true,
            "k12.pr.us": true,
            "k12.ri.us": true,
            "k12.sc.us": true,
            "k12.sd.us": true,
            "k12.tn.us": true,
            "k12.tx.us": true,
            "k12.ut.us": true,
            "k12.vi.us": true,
            "k12.vt.us": true,
            "k12.va.us": true,
            "k12.wa.us": true,
            "k12.wi.us": true,
            "k12.wv.us": true,
            "k12.wy.us": true,
            "cc.ak.us": true,
            "cc.al.us": true,
            "cc.ar.us": true,
            "cc.as.us": true,
            "cc.az.us": true,
            "cc.ca.us": true,
            "cc.co.us": true,
            "cc.ct.us": true,
            "cc.dc.us": true,
            "cc.de.us": true,
            "cc.fl.us": true,
            "cc.ga.us": true,
            "cc.gu.us": true,
            "cc.hi.us": true,
            "cc.ia.us": true,
            "cc.id.us": true,
            "cc.il.us": true,
            "cc.in.us": true,
            "cc.ks.us": true,
            "cc.ky.us": true,
            "cc.la.us": true,
            "cc.ma.us": true,
            "cc.md.us": true,
            "cc.me.us": true,
            "cc.mi.us": true,
            "cc.mn.us": true,
            "cc.mo.us": true,
            "cc.ms.us": true,
            "cc.mt.us": true,
            "cc.nc.us": true,
            "cc.nd.us": true,
            "cc.ne.us": true,
            "cc.nh.us": true,
            "cc.nj.us": true,
            "cc.nm.us": true,
            "cc.nv.us": true,
            "cc.ny.us": true,
            "cc.oh.us": true,
            "cc.ok.us": true,
            "cc.or.us": true,
            "cc.pa.us": true,
            "cc.pr.us": true,
            "cc.ri.us": true,
            "cc.sc.us": true,
            "cc.sd.us": true,
            "cc.tn.us": true,
            "cc.tx.us": true,
            "cc.ut.us": true,
            "cc.vi.us": true,
            "cc.vt.us": true,
            "cc.va.us": true,
            "cc.wa.us": true,
            "cc.wi.us": true,
            "cc.wv.us": true,
            "cc.wy.us": true,
            "lib.ak.us": true,
            "lib.al.us": true,
            "lib.ar.us": true,
            "lib.as.us": true,
            "lib.az.us": true,
            "lib.ca.us": true,
            "lib.co.us": true,
            "lib.ct.us": true,
            "lib.dc.us": true,
            "lib.de.us": true,
            "lib.fl.us": true,
            "lib.ga.us": true,
            "lib.gu.us": true,
            "lib.hi.us": true,
            "lib.ia.us": true,
            "lib.id.us": true,
            "lib.il.us": true,
            "lib.in.us": true,
            "lib.ks.us": true,
            "lib.ky.us": true,
            "lib.la.us": true,
            "lib.ma.us": true,
            "lib.md.us": true,
            "lib.me.us": true,
            "lib.mi.us": true,
            "lib.mn.us": true,
            "lib.mo.us": true,
            "lib.ms.us": true,
            "lib.mt.us": true,
            "lib.nc.us": true,
            "lib.nd.us": true,
            "lib.ne.us": true,
            "lib.nh.us": true,
            "lib.nj.us": true,
            "lib.nm.us": true,
            "lib.nv.us": true,
            "lib.ny.us": true,
            "lib.oh.us": true,
            "lib.ok.us": true,
            "lib.or.us": true,
            "lib.pa.us": true,
            "lib.pr.us": true,
            "lib.ri.us": true,
            "lib.sc.us": true,
            "lib.sd.us": true,
            "lib.tn.us": true,
            "lib.tx.us": true,
            "lib.ut.us": true,
            "lib.vi.us": true,
            "lib.vt.us": true,
            "lib.va.us": true,
            "lib.wa.us": true,
            "lib.wi.us": true,
            "lib.wv.us": true,
            "lib.wy.us": true,
            "pvt.k12.ma.us": true,
            "chtr.k12.ma.us": true,
            "paroch.k12.ma.us": true,
            "*.uy": true,
            "uz": true,
            "com.uz": true,
            "co.uz": true,
            "va": true,
            "vc": true,
            "com.vc": true,
            "net.vc": true,
            "org.vc": true,
            "gov.vc": true,
            "mil.vc": true,
            "edu.vc": true,
            "*.ve": true,
            "vg": true,
            "vi": true,
            "co.vi": true,
            "com.vi": true,
            "k12.vi": true,
            "net.vi": true,
            "org.vi": true,
            "vn": true,
            "com.vn": true,
            "net.vn": true,
            "org.vn": true,
            "edu.vn": true,
            "gov.vn": true,
            "int.vn": true,
            "ac.vn": true,
            "biz.vn": true,
            "info.vn": true,
            "name.vn": true,
            "pro.vn": true,
            "health.vn": true,
            "vu": true,
            "wf": true,
            "ws": true,
            "com.ws": true,
            "net.ws": true,
            "org.ws": true,
            "gov.ws": true,
            "edu.ws": true,
            "yt": true,
            "xn--mgbaam7a8h": true,
            "xn--54b7fta0cc": true,
            "xn--fiqs8s": true,
            "xn--fiqz9s": true,
            "xn--lgbbat1ad8j": true,
            "xn--wgbh1c": true,
            "xn--node": true,
            "xn--j6w193g": true,
            "xn--h2brj9c": true,
            "xn--mgbbh1a71e": true,
            "xn--fpcrj9c3d": true,
            "xn--gecrj9c": true,
            "xn--s9brj9c": true,
            "xn--45brj9c": true,
            "xn--xkc2dl3a5ee0h": true,
            "xn--mgba3a4f16a": true,
            "xn--mgba3a4fra": true,
            "xn--mgbayh7gpa": true,
            "xn--3e0b707e": true,
            "xn--fzc2c9e2c": true,
            "xn--xkc2al3hye2a": true,
            "xn--mgbc0a9azcg": true,
            "xn--mgb9awbf": true,
            "xn--ygbi2ammx": true,
            "xn--90a3ac": true,
            "xn--p1ai": true,
            "xn--wgbl6a": true,
            "xn--mgberp4a5d4ar": true,
            "xn--mgberp4a5d4a87g": true,
            "xn--mgbqly7c0a67fbc": true,
            "xn--mgbqly7cvafr": true,
            "xn--ogbpf8fl": true,
            "xn--mgbtf8fl": true,
            "xn--yfro4i67o": true,
            "xn--clchc0ea0b2g2a9gcd": true,
            "xn--o3cw4h": true,
            "xn--pgbs0dh": true,
            "xn--kpry57d": true,
            "xn--kprw13d": true,
            "xn--nnx388a": true,
            "xn--j1amh": true,
            "xn--mgb2ddes": true,
            "xxx": true,
            "*.ye": true,
            "*.za": true,
            "*.zm": true,
            "*.zw": true,
            "biz.at": true,
            "info.at": true,
            "priv.at": true,
            "co.ca": true,
            "ar.com": true,
            "br.com": true,
            "cn.com": true,
            "de.com": true,
            "eu.com": true,
            "gb.com": true,
            "gr.com": true,
            "hu.com": true,
            "jpn.com": true,
            "kr.com": true,
            "no.com": true,
            "qc.com": true,
            "ru.com": true,
            "sa.com": true,
            "se.com": true,
            "uk.com": true,
            "us.com": true,
            "uy.com": true,
            "za.com": true,
            "gb.net": true,
            "jp.net": true,
            "se.net": true,
            "uk.net": true,
            "ae.org": true,
            "us.org": true,
            "com.de": true,
            "operaunite.com": true,
            "appspot.com": true,
            "iki.fi": true,
            "c.la": true,
            "za.net": true,
            "za.org": true,
            "co.nl": true,
            "co.no": true,
            "co.pl": true,
            "dyndns-at-home.com": true,
            "dyndns-at-work.com": true,
            "dyndns-blog.com": true,
            "dyndns-free.com": true,
            "dyndns-home.com": true,
            "dyndns-ip.com": true,
            "dyndns-mail.com": true,
            "dyndns-office.com": true,
            "dyndns-pics.com": true,
            "dyndns-remote.com": true,
            "dyndns-server.com": true,
            "dyndns-web.com": true,
            "dyndns-wiki.com": true,
            "dyndns-work.com": true,
            "dyndns.biz": true,
            "dyndns.info": true,
            "dyndns.org": true,
            "dyndns.tv": true,
            "at-band-camp.net": true,
            "ath.cx": true,
            "barrel-of-knowledge.info": true,
            "barrell-of-knowledge.info": true,
            "better-than.tv": true,
            "blogdns.com": true,
            "blogdns.net": true,
            "blogdns.org": true,
            "blogsite.org": true,
            "boldlygoingnowhere.org": true,
            "broke-it.net": true,
            "buyshouses.net": true,
            "cechire.com": true,
            "dnsalias.com": true,
            "dnsalias.net": true,
            "dnsalias.org": true,
            "dnsdojo.com": true,
            "dnsdojo.net": true,
            "dnsdojo.org": true,
            "does-it.net": true,
            "doesntexist.com": true,
            "doesntexist.org": true,
            "dontexist.com": true,
            "dontexist.net": true,
            "dontexist.org": true,
            "doomdns.com": true,
            "doomdns.org": true,
            "dvrdns.org": true,
            "dyn-o-saur.com": true,
            "dynalias.com": true,
            "dynalias.net": true,
            "dynalias.org": true,
            "dynathome.net": true,
            "dyndns.ws": true,
            "endofinternet.net": true,
            "endofinternet.org": true,
            "endoftheinternet.org": true,
            "est-a-la-maison.com": true,
            "est-a-la-masion.com": true,
            "est-le-patron.com": true,
            "est-mon-blogueur.com": true,
            "for-better.biz": true,
            "for-more.biz": true,
            "for-our.info": true,
            "for-some.biz": true,
            "for-the.biz": true,
            "forgot.her.name": true,
            "forgot.his.name": true,
            "from-ak.com": true,
            "from-al.com": true,
            "from-ar.com": true,
            "from-az.net": true,
            "from-ca.com": true,
            "from-co.net": true,
            "from-ct.com": true,
            "from-dc.com": true,
            "from-de.com": true,
            "from-fl.com": true,
            "from-ga.com": true,
            "from-hi.com": true,
            "from-ia.com": true,
            "from-id.com": true,
            "from-il.com": true,
            "from-in.com": true,
            "from-ks.com": true,
            "from-ky.com": true,
            "from-la.net": true,
            "from-ma.com": true,
            "from-md.com": true,
            "from-me.org": true,
            "from-mi.com": true,
            "from-mn.com": true,
            "from-mo.com": true,
            "from-ms.com": true,
            "from-mt.com": true,
            "from-nc.com": true,
            "from-nd.com": true,
            "from-ne.com": true,
            "from-nh.com": true,
            "from-nj.com": true,
            "from-nm.com": true,
            "from-nv.com": true,
            "from-ny.net": true,
            "from-oh.com": true,
            "from-ok.com": true,
            "from-or.com": true,
            "from-pa.com": true,
            "from-pr.com": true,
            "from-ri.com": true,
            "from-sc.com": true,
            "from-sd.com": true,
            "from-tn.com": true,
            "from-tx.com": true,
            "from-ut.com": true,
            "from-va.com": true,
            "from-vt.com": true,
            "from-wa.com": true,
            "from-wi.com": true,
            "from-wv.com": true,
            "from-wy.com": true,
            "ftpaccess.cc": true,
            "fuettertdasnetz.de": true,
            "game-host.org": true,
            "game-server.cc": true,
            "getmyip.com": true,
            "gets-it.net": true,
            "go.dyndns.org": true,
            "gotdns.com": true,
            "gotdns.org": true,
            "groks-the.info": true,
            "groks-this.info": true,
            "ham-radio-op.net": true,
            "here-for-more.info": true,
            "hobby-site.com": true,
            "hobby-site.org": true,
            "home.dyndns.org": true,
            "homedns.org": true,
            "homeftp.net": true,
            "homeftp.org": true,
            "homeip.net": true,
            "homelinux.com": true,
            "homelinux.net": true,
            "homelinux.org": true,
            "homeunix.com": true,
            "homeunix.net": true,
            "homeunix.org": true,
            "iamallama.com": true,
            "in-the-band.net": true,
            "is-a-anarchist.com": true,
            "is-a-blogger.com": true,
            "is-a-bookkeeper.com": true,
            "is-a-bruinsfan.org": true,
            "is-a-bulls-fan.com": true,
            "is-a-candidate.org": true,
            "is-a-caterer.com": true,
            "is-a-celticsfan.org": true,
            "is-a-chef.com": true,
            "is-a-chef.net": true,
            "is-a-chef.org": true,
            "is-a-conservative.com": true,
            "is-a-cpa.com": true,
            "is-a-cubicle-slave.com": true,
            "is-a-democrat.com": true,
            "is-a-designer.com": true,
            "is-a-doctor.com": true,
            "is-a-financialadvisor.com": true,
            "is-a-geek.com": true,
            "is-a-geek.net": true,
            "is-a-geek.org": true,
            "is-a-green.com": true,
            "is-a-guru.com": true,
            "is-a-hard-worker.com": true,
            "is-a-hunter.com": true,
            "is-a-knight.org": true,
            "is-a-landscaper.com": true,
            "is-a-lawyer.com": true,
            "is-a-liberal.com": true,
            "is-a-libertarian.com": true,
            "is-a-linux-user.org": true,
            "is-a-llama.com": true,
            "is-a-musician.com": true,
            "is-a-nascarfan.com": true,
            "is-a-nurse.com": true,
            "is-a-painter.com": true,
            "is-a-patsfan.org": true,
            "is-a-personaltrainer.com": true,
            "is-a-photographer.com": true,
            "is-a-player.com": true,
            "is-a-republican.com": true,
            "is-a-rockstar.com": true,
            "is-a-socialist.com": true,
            "is-a-soxfan.org": true,
            "is-a-student.com": true,
            "is-a-teacher.com": true,
            "is-a-techie.com": true,
            "is-a-therapist.com": true,
            "is-an-accountant.com": true,
            "is-an-actor.com": true,
            "is-an-actress.com": true,
            "is-an-anarchist.com": true,
            "is-an-artist.com": true,
            "is-an-engineer.com": true,
            "is-an-entertainer.com": true,
            "is-by.us": true,
            "is-certified.com": true,
            "is-found.org": true,
            "is-gone.com": true,
            "is-into-anime.com": true,
            "is-into-cars.com": true,
            "is-into-cartoons.com": true,
            "is-into-games.com": true,
            "is-leet.com": true,
            "is-lost.org": true,
            "is-not-certified.com": true,
            "is-saved.org": true,
            "is-slick.com": true,
            "is-uberleet.com": true,
            "is-very-bad.org": true,
            "is-very-evil.org": true,
            "is-very-good.org": true,
            "is-very-nice.org": true,
            "is-very-sweet.org": true,
            "is-with-theband.com": true,
            "isa-geek.com": true,
            "isa-geek.net": true,
            "isa-geek.org": true,
            "isa-hockeynut.com": true,
            "issmarterthanyou.com": true,
            "isteingeek.de": true,
            "istmein.de": true,
            "kicks-ass.net": true,
            "kicks-ass.org": true,
            "knowsitall.info": true,
            "land-4-sale.us": true,
            "lebtimnetz.de": true,
            "leitungsen.de": true,
            "likes-pie.com": true,
            "likescandy.com": true,
            "merseine.nu": true,
            "mine.nu": true,
            "misconfused.org": true,
            "mypets.ws": true,
            "myphotos.cc": true,
            "neat-url.com": true,
            "office-on-the.net": true,
            "on-the-web.tv": true,
            "podzone.net": true,
            "podzone.org": true,
            "readmyblog.org": true,
            "saves-the-whales.com": true,
            "scrapper-site.net": true,
            "scrapping.cc": true,
            "selfip.biz": true,
            "selfip.com": true,
            "selfip.info": true,
            "selfip.net": true,
            "selfip.org": true,
            "sells-for-less.com": true,
            "sells-for-u.com": true,
            "sells-it.net": true,
            "sellsyourhome.org": true,
            "servebbs.com": true,
            "servebbs.net": true,
            "servebbs.org": true,
            "serveftp.net": true,
            "serveftp.org": true,
            "servegame.org": true,
            "shacknet.nu": true,
            "simple-url.com": true,
            "space-to-rent.com": true,
            "stuff-4-sale.org": true,
            "stuff-4-sale.us": true,
            "teaches-yoga.com": true,
            "thruhere.net": true,
            "traeumtgerade.de": true,
            "webhop.biz": true,
            "webhop.info": true,
            "webhop.net": true,
            "webhop.org": true,
            "worse-than.tv": true,
            "writesthisblog.com": true
        });

    var urlParse = function (url) {
        var parser = document.createElement('a');
        parser.href = url;
        return parser;
    };

    function MemoryCookieStore(firebaseEndpoint) {
        this.idx = {};
        this.firebaseEndpoint = firebaseEndpoint;
    }

    var MemoryCookieStore = MemoryCookieStore;
    MemoryCookieStore.prototype.idx = null;
    MemoryCookieStore.prototype.synchronous = true;

// force a default depth:
    MemoryCookieStore.prototype.inspect = function () {
        return "{ idx: " + util.inspect(this.idx, false, 2) + ' }';
    };

    MemoryCookieStore.prototype.findCookie = function (domain, path, key, cb) {
        if (!this.idx[domain]) {
            return cb(null, undefined);
        }
        if (!this.idx[domain][path]) {
            return cb(null, undefined);
        }
        return cb(null, this.idx[domain][path][key] || null);
    };

    MemoryCookieStore.prototype.findCookies = function (domain, path) {
        var results = [];
        if (!domain) {
            return [];
        }

        var pathMatcher;
        if (!path) {
            // null or '/' means "all paths"
            pathMatcher = function matchAll(domainIndex) {
                for (var curPath in domainIndex) {
                    var pathIndex = domainIndex[curPath];
                    for (var key in pathIndex) {
                        results.push(pathIndex[key]);
                    }
                }
            };

        } else if (path === '/') {
            pathMatcher = function matchSlash(domainIndex) {
                var pathIndex = domainIndex['/'];
                if (!pathIndex) {
                    return;
                }
                for (var key in pathIndex) {
                    results.push(pathIndex[key]);
                }
            };

        } else {
            var paths = permutePath(path) || [path];
            pathMatcher = function matchRFC(domainIndex) {
                paths.forEach(function (curPath) {
                    var pathIndex = domainIndex[curPath];
                    if (!pathIndex) {
                        return;
                    }
                    for (var key in pathIndex) {
                        results.push(pathIndex[key]);
                    }
                });
            };
        }

        var domains = permuteDomain(domain) || [domain];
        var idx = this.idx;
        domains.forEach(function (curDomain) {
            var domainIndex = idx[curDomain];
            if (!domainIndex) {
                return;
            }
            pathMatcher(domainIndex);
        });

        return results;
    };

    MemoryCookieStore.prototype.putCookie = function (cookie, cb) {
        if (!this.idx[cookie.domain]) {
            this.idx[cookie.domain] = {};
        }
        if (!this.idx[cookie.domain][cookie.path]) {
            this.idx[cookie.domain][cookie.path] = {};
        }
        this.idx[cookie.domain][cookie.path][cookie.key] = cookie;
        var cookieKey = btoa(cookie.domain + ';' + cookie.path + ";" + cookie.key);
        /*this.firebaseEndpoint.child(cookieKey)
            .set({setCookie: cookie.toString(), domain: cookie.domain, path: cookie.path, keepAliveUrl: firstAccessUrls[cookieKey] ? firstAccessUrls[cookieKey] : null});*/
        cb(null);
    };

    MemoryCookieStore.prototype.updateCookie = function updateCookie(oldCookie, newCookie, cb) {
        // updateCookie() may avoid updating cookies that are identical.  For example,
        // lastAccessed may not be important to some stores and an equalitygetPublicSuffix
        // comparison could exclude that field.
        this.putCookie(newCookie, cb);
    };

    MemoryCookieStore.prototype.removeCookie = function removeCookie(domain, path, key, cb) {
        if (this.idx[domain] && this.idx[domain][path] && this.idx[domain][path][key]) {
            delete this.idx[domain][path][key];
        }
        //this.firebaseEndpoint.child(btoa(domain + ';' + path + ";" + key)).remove();
        cb(null);
    };

    MemoryCookieStore.prototype.removeCookies = function removeCookies(domain, path, cb) {
        if (this.idx[domain]) {
            if (path) {
                delete this.idx[domain][path];
            } else {
                delete this.idx[domain];
            }
        }
        return cb(null);
    };


    var DATE_DELIM = /[\x09\x20-\x2F\x3B-\x40\x5B-\x60\x7B-\x7E]/;

// From RFC2616 S2.2:
    var TOKEN = /[\x21\x23-\x26\x2A\x2B\x2D\x2E\x30-\x39\x41-\x5A\x5E-\x7A\x7C\x7E]/;

// From RFC6265 S4.1.1
// note that it excludes \x3B ";"
    var COOKIE_OCTET = /[\x21\x23-\x2B\x2D-\x3A\x3C-\x5B\x5D-\x7E]/;
    var COOKIE_OCTETS = new RegExp('^' + COOKIE_OCTET.source + '$');

// The name/key cannot be empty but the value can (S5.2):
    var COOKIE_PAIR_STRICT = new RegExp('^(' + TOKEN.source + '+)=("?)(' + COOKIE_OCTET.source + '*)\\2$');
    var COOKIE_PAIR = /^([^=\s]+)\s*=\s*("?)\s*(.*)\s*\2\s*$/;

// RFC6265 S4.1.1 defines extension-av as 'any CHAR except CTLs or ";"'
// Note ';' is \x3B
    var NON_CTL_SEMICOLON = /[\x20-\x3A\x3C-\x7E]+/;
    var EXTENSION_AV = NON_CTL_SEMICOLON;
    var PATH_VALUE = NON_CTL_SEMICOLON;

// Used for checking whether or not there is a trailing semi-colon
    var TRAILING_SEMICOLON = /;+$/;

    /* RFC6265 S5.1.1.5:
     * [fail if] the day-of-month-value is less than 1 or greater than 31
     */
    var DAY_OF_MONTH = /^(0?[1-9]|[12][0-9]|3[01])$/;

    /* RFC6265 S5.1.1.5:
     * [fail if]
     * *  the hour-value is greater than 23,
     * *  the minute-value is greater than 59, or
     * *  the second-value is greater than 59.
     */
    var TIME = /(0?[0-9]|1[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])/;
    var STRICT_TIME = /^(0?[0-9]|1[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$/;

    var MONTH = /^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)$/i;
    var MONTH_TO_NUM = {
        jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5,
        jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11
    };
    var NUM_TO_MONTH = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    var NUM_TO_DAY = [
        'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'
    ];

    var YEAR = /^([1-9][0-9]{1,3})$/; // 2 to 4 digits

    var MAX_TIME = 2147483647000; // 31-bit max
    var MIN_TIME = 0; // 31-bit min


// RFC6265 S5.1.1 date parser:
    function parseDate(str, strict) {
        if (!str) {
            return;
        }
        var found_time, found_dom, found_month, found_year;

        /* RFC6265 S5.1.1:
         * 2. Process each date-token sequentially in the order the date-tokens
         * appear in the cookie-date
         */
        var tokens = str.split(DATE_DELIM);
        if (!tokens) {
            return;
        }

        var date = new Date();
        date.setMilliseconds(0);

        for (var i = 0; i < tokens.length; i++) {
            var token = tokens[i].trim();
            if (!token.length) {
                continue;
            }

            var result;

            /* 2.1. If the found-time flag is not set and the token matches the time
             * production, set the found-time flag and set the hour- value,
             * minute-value, and second-value to the numbers denoted by the digits in
             * the date-token, respectively.  Skip the remaining sub-steps and continue
             * to the next date-token.
             */
            if (!found_time) {
                result = (strict ? STRICT_TIME : TIME).exec(token);
                if (result) {
                    found_time = true;
                    date.setUTCHours(result[1]);
                    date.setUTCMinutes(result[2]);
                    date.setUTCSeconds(result[3]);
                    continue;
                }
            }

            /* 2.2. If the found-day-of-month flag is not set and the date-token matches
             * the day-of-month production, set the found-day-of- month flag and set
             * the day-of-month-value to the number denoted by the date-token.  Skip
             * the remaining sub-steps and continue to the next date-token.
             */
            if (!found_dom) {
                result = DAY_OF_MONTH.exec(token);
                if (result) {
                    found_dom = true;
                    date.setUTCDate(result[1]);
                    continue;
                }
            }

            /* 2.3. If the found-month flag is not set and the date-token matches the
             * month production, set the found-month flag and set the month-value to
             * the month denoted by the date-token.  Skip the remaining sub-steps and
             * continue to the next date-token.
             */
            if (!found_month) {
                result = MONTH.exec(token);
                if (result) {
                    found_month = true;
                    date.setUTCMonth(MONTH_TO_NUM[result[1].toLowerCase()]);
                    continue;
                }
            }

            /* 2.4. If the found-year flag is not set and the date-token matches the year
             * production, set the found-year flag and set the year-value to the number
             * denoted by the date-token.  Skip the remaining sub-steps and continue to
             * the next date-token.
             */
            if (!found_year) {
                result = YEAR.exec(token);
                if (result) {
                    var year = result[0];
                    /* From S5.1.1:
                     * 3.  If the year-value is greater than or equal to 70 and less
                     * than or equal to 99, increment the year-value by 1900.
                     * 4.  If the year-value is greater than or equal to 0 and less
                     * than or equal to 69, increment the year-value by 2000.
                     */
                    if (70 <= year && year <= 99) {
                        year += 1900;
                    } else if (0 <= year && year <= 69) {
                        year += 2000;
                    }

                    if (year < 1601) {
                        return; // 5. ... the year-value is less than 1601
                    }

                    found_year = true;
                    date.setUTCFullYear(year);
                    continue;
                }
            }
        }

        if (!(found_time && found_dom && found_month && found_year)) {
            return; // 5. ... at least one of the found-day-of-month, found-month, found-
                    // year, or found-time flags is not set,
        }

        return date;
    }

    function formatDate(date) {
        var d = date.getUTCDate();
        d = d >= 10 ? d : '0' + d;
        var h = date.getUTCHours();
        h = h >= 10 ? h : '0' + h;
        var m = date.getUTCMinutes();
        m = m >= 10 ? m : '0' + m;
        var s = date.getUTCSeconds();
        s = s >= 10 ? s : '0' + s;
        return NUM_TO_DAY[date.getUTCDay()] + ', ' +
            d + ' ' + NUM_TO_MONTH[date.getUTCMonth()] + ' ' + date.getUTCFullYear() + ' ' +
            h + ':' + m + ':' + s + ' GMT';
    }

// S5.1.2 Canonicalized Host Names
    function canonicalDomain(str) {
        if (str == null) {
            return null;
        }
        str = str.trim().replace(/^\./, ''); // S4.1.2.3 & S5.2.3: ignore leading .


        return str.toLowerCase();
    }

// S5.1.3 Domain Matching
    function domainMatch(str, domStr, canonicalize) {
        if (str == null || domStr == null) {
            return null;
        }
        if (canonicalize !== false) {
            str = canonicalDomain(str);
            domStr = canonicalDomain(domStr);
        }

        /*
         * "The domain string and the string are identical. (Note that both the
         * domain string and the string will have been canonicalized to lower case at
         * this point)"
         */
        if (str == domStr) {
            return true;
        }

        /* "All of the following [three] conditions hold:" (order adjusted from the RFC) */

        /* "* The string is a host name (i.e., not an IP address)." */


        /* "* The domain string is a suffix of the string" */
        var idx = str.indexOf(domStr);
        if (idx <= 0) {
            return false; // it's a non-match (-1) or prefix (0)
        }

        // e.g "a.b.c".indexOf("b.c") === 2
        // 5 === 3+2
        if (str.length !== domStr.length + idx) { // it's not a suffix
            return false;
        }

        /* "* The last character of the string that is not included in the domain
         * string is a %x2E (".") character." */
        if (str.substr(idx - 1, 1) !== '.') {
            return false;
        }

        return true;
    }


// RFC6265 S5.1.4 Paths and Path-Match

    /*
     * "The user agent MUST use an algorithm equivalent to the following algorithm
     * to compute the default-path of a cookie:"
     *
     * Assumption: the path (and not query part or absolute uri) is passed in.
     */
    function defaultPath(path) {
        // "2. If the uri-path is empty or if the first character of the uri-path is not
        // a %x2F ("/") character, output %x2F ("/") and skip the remaining steps.
        if (!path || path.substr(0, 1) !== "/") {
            return "/";
        }

        // "3. If the uri-path contains no more than one %x2F ("/") character, output
        // %x2F ("/") and skip the remaining step."
        if (path === "/") {
            return path;
        }

        var rightSlash = path.lastIndexOf("/");
        if (rightSlash === 0) {
            return "/";
        }

        // "4. Output the characters of the uri-path from the first character up to,
        // but not including, the right-most %x2F ("/")."
        return path.slice(0, rightSlash);
    }

    /*
     * "A request-path path-matches a given cookie-path if at least one of the
     * following conditions holds:"
     */
    function pathMatch(reqPath, cookiePath) {
        // "o  The cookie-path and the request-path are identical."
        if (cookiePath === reqPath) {
            return true;
        }

        var idx = reqPath.indexOf(cookiePath);
        if (idx === 0) {
            // "o  The cookie-path is a prefix of the request-path, and the last
            // character of the cookie-path is %x2F ("/")."
            if (cookiePath.substr(-1) === "/") {
                return true;
            }

            // " o  The cookie-path is a prefix of the request-path, and the first
            // character of the request-path that is not included in the cookie- path
            // is a %x2F ("/") character."
            if (reqPath.substr(cookiePath.length, 1) === "/") {
                return true;
            }
        }

        return false;
    }

    function parse(str, strict) {
        str = str.trim();

        // S4.1.1 Trailing semi-colons are not part of the specification.
        // If we are not in strict mode we remove the trailing semi-colons.
        var semiColonCheck = TRAILING_SEMICOLON.exec(str);
        if (semiColonCheck) {
            if (strict) {
                return;
            }
            str = str.slice(0, semiColonCheck.index);
        }

        // We use a regex to parse the "name-value-pair" part of S5.2
        var firstSemi = str.indexOf(';'); // S5.2 step 1
        var pairRx = strict ? COOKIE_PAIR_STRICT : COOKIE_PAIR;
        var result = pairRx.exec(firstSemi === -1 ? str : str.substr(0, firstSemi));

        // Rx satisfies the "the name string is empty" and "lacks a %x3D ("=")"
        // constraints as well as trimming any whitespace.
        if (!result) {
            return;
        }

        var c = new Cookie();
        c.key = result[1]; // the regexp should trim() already
        c.value = result[3]; // [2] is quotes or empty-string

        if (firstSemi === -1) {
            return c;
        }

        // S5.2.3 "unparsed-attributes consist of the remainder of the set-cookie-string
        // (including the %x3B (";") in question)." plus later on in the same section
        // "discard the first ";" and trim".
        var unparsed = str.slice(firstSemi).replace(/^\s*;\s*/, '').trim();

        // "If the unparsed-attributes string is empty, skip the rest of these
        // steps."
        if (unparsed.length === 0) {
            return c;
        }

        /*
         * S5.2 says that when looping over the items "[p]rocess the attribute-name
         * and attribute-value according to the requirements in the following
         * subsections" for every item.  Plus, for many of the individual attributes
         * in S5.3 it says to use the "attribute-value of the last attribute in the
         * cookie-attribute-list".  Therefore, in this implementation, we overwrite
         * the previous value.
         */
        var cookie_avs = unparsed.split(/\s*;\s*/);
        while (cookie_avs.length) {
            var av = cookie_avs.shift();

            if (strict && !EXTENSION_AV.test(av)) {
                return;
            }

            var av_sep = av.indexOf('=');
            var av_key, av_value;
            if (av_sep === -1) {
                av_key = av;
                av_value = null;
            } else {
                av_key = av.substr(0, av_sep);
                av_value = av.substr(av_sep + 1);
            }

            av_key = av_key.trim().toLowerCase();
            if (av_value) {
                av_value = av_value.trim();
            }

            switch (av_key) {
                case 'expires': // S5.2.1
                    if (!av_value) {
                        if (strict) {
                            return;
                        } else {
                            break;
                        }
                    }
                    var exp = parseDate(av_value, strict);
                    // "If the attribute-value failed to parse as a cookie date, ignore the
                    // cookie-av."
                    if (exp == null) {
                        if (strict) {
                            return;
                        } else {
                            break;
                        }
                    }
                    c.expires = exp;
                    // over and underflow not realistically a concern: V8's getTime() seems to
                    // store something larger than a 32-bit time_t (even with 32-bit node)
                    break;

                case 'max-age': // S5.2.2
                    if (!av_value) {
                        if (strict) {
                            return;
                        } else {
                            break;
                        }
                    }
                    // "If the first character of the attribute-value is not a DIGIT or a "-"
                    // character ...[or]... If the remainder of attribute-value contains a
                    // non-DIGIT character, ignore the cookie-av."
                    if (!/^-?[0-9]+$/.test(av_value)) {
                        if (strict) {
                            return;
                        } else {
                            break;
                        }
                    }
                    var delta = parseInt(av_value, 10);
                    if (strict && delta <= 0) {
                        return; // S4.1.1
                    }
                    // "If delta-seconds is less than or equal to zero (0), let expiry-time
                    // be the earliest representable date and time."
                    c.setMaxAge(delta);
                    break;

                case 'domain': // S5.2.3
                    // "If the attribute-value is empty, the behavior is undefined.  However,
                    // the user agent SHOULD ignore the cookie-av entirely."
                    if (!av_value) {
                        if (strict) {
                            return;
                        } else {
                            break;
                        }
                    }
                    // S5.2.3 "Let cookie-domain be the attribute-value without the leading %x2E
                    // (".") character."
                    var domain = av_value.trim().replace(/^\./, '');
                    if (!domain) {
                        if (strict) {
                            return;
                        } else {
                            break;
                        }
                    } // see "is empty" above
                    // "Convert the cookie-domain to lower case."
                    c.domain = domain.toLowerCase();
                    break;

                case 'path': // S5.2.4
                    /*
                     * "If the attribute-value is empty or if the first character of the
                     * attribute-value is not %x2F ("/"):
                     *   Let cookie-path be the default-path.
                     * Otherwise:
                     *   Let cookie-path be the attribute-value."
                     *
                     * We'll represent the default-path as null since it depends on the
                     * context of the parsing.
                     */
                    if (!av_value || av_value.substr(0, 1) != "/") {
                        if (strict) {
                            return;
                        } else {
                            break;
                        }
                    }
                    c.path = av_value;
                    break;

                case 'secure': // S5.2.5
                    /*
                     * "If the attribute-name case-insensitively matches the string "Secure",
                     * the user agent MUST append an attribute to the cookie-attribute-list
                     * with an attribute-name of Secure and an empty attribute-value."
                     */
                    if (av_value != null) {
                        if (strict) {
                            return;
                        }
                    }
                    c.secure = true;
                    break;

                case 'httponly': // S5.2.6 -- effectively the same as 'secure'
                    if (av_value != null) {
                        if (strict) {
                            return;
                        }
                    }
                    c.httpOnly = true;
                    break;

                default:
                    c.extensions = c.extensions || [];
                    c.extensions.push(av);
                    break;
            }
        }

        // ensure a default date for sorting:
        c.creation = new Date();
        return c;
    }

    function fromJSON(str) {
        if (!str) {
            return null;
        }

        var obj;
        try {
            obj = JSON.parse(str);
        } catch (e) {
            return null;
        }

        var c = new Cookie();
        for (var i = 0; i < numCookieProperties; i++) {
            var prop = cookieProperties[i];
            if (obj[prop] == null) {
                continue;
            }
            if (prop === 'expires' ||
                prop === 'creation' ||
                prop === 'lastAccessed') {
                c[prop] = obj[prop] == "Infinity" ? "Infinity" : new Date(obj[prop]);
            } else {
                c[prop] = obj[prop];
            }
        }


        // ensure a default date for sorting:
        c.creation = c.creation || new Date();

        return c;
    }

    /* Section 5.4 part 2:
     * "*  Cookies with longer paths are listed before cookies with
     *     shorter paths.
     *
     *  *  Among cookies that have equal-length path fields, cookies with
     *     earlier creation-times are listed before cookies with later
     *     creation-times."
     */

    function cookieCompare(a, b) {
        // descending for length: b CMP a
        var deltaLen = (b.path ? b.path.length : 0) - (a.path ? a.path.length : 0);
        if (deltaLen !== 0) {
            return deltaLen;
        }
        // ascending for time: a CMP b
        return (a.creation ? a.creation.getTime() : MAX_TIME) -
            (b.creation ? b.creation.getTime() : MAX_TIME);
    }

// Gives the permutation of all possible domainMatch()es of a given domain. The
// array is in shortest-to-longest order.  Handy for indexing.
    function permuteDomain(domain) {
        var pubSuf = getPublicSuffix(domain);
        if (!pubSuf) {
            return null;
        }
        if (pubSuf == domain) {
            return [domain];
        }

        var prefix = domain.slice(0, -(pubSuf.length + 1)); // ".example.com"
        var parts = prefix.split('.').reverse();
        var cur = pubSuf;
        var permutations = [cur];
        while (parts.length) {
            cur = parts.shift() + '.' + cur;
            permutations.push(cur);
        }
        return permutations;
    }

// Gives the permutation of all possible pathMatch()es of a given path. The
// array is in longest-to-shortest order.  Handy for indexing.
    function permutePath(path) {
        if (path === '/') {
            return ['/'];
        }
        if (path.lastIndexOf('/') === path.length - 1) {
            path = path.substr(0, path.length - 1);
        }
        var permutations = [path];
        while (path.length > 1) {
            var lindex = path.lastIndexOf('/');
            if (lindex === 0) {
                break;
            }
            path = path.substr(0, lindex);
            permutations.push(path);
        }
        permutations.push('/');
        return permutations;
    }


    function Cookie(opts) {
        if (typeof opts !== "object") {
            return;
        }
        Object.keys(opts).forEach(function (key) {
            if (Cookie.prototype.hasOwnProperty(key)) {
                this[key] = opts[key] || Cookie.prototype[key];
            }
        }.bind(this));
    }

    Cookie.parse = parse;
    Cookie.fromJSON = fromJSON;

    Cookie.prototype.key = "";
    Cookie.prototype.value = "";
    Cookie.prototype.firstAccessedFrom = null;

// the order in which the RFC has them:
    Cookie.prototype.expires = "Infinity"; // coerces to literal Infinity
    Cookie.prototype.maxAge = null; // takes precedence over expires for TTL
    Cookie.prototype.domain = null;
    Cookie.prototype.path = null;
    Cookie.prototype.secure = false;
    Cookie.prototype.httpOnly = false;
    Cookie.prototype.extensions = null;

// set by the CookieJar:
    Cookie.prototype.hostOnly = null; // boolean when set
    Cookie.prototype.pathIsDefault = null; // boolean when set
    Cookie.prototype.creation = null; // Date when set; defaulted by Cookie.parse
    Cookie.prototype.lastAccessed = null; // Date when set
    cookieJar.Cookie = Cookie;

    var cookieProperties = Object.freeze(Object.keys(Cookie.prototype).map(function (p) {
        if (p instanceof Function) {
            return;
        }
        return p;
    }));
    var numCookieProperties = cookieProperties.length;

    Cookie.prototype.inspect = function inspect() {
        var now = Date.now();
        return 'Cookie="' + this.toString() +
            '; hostOnly=' + (this.hostOnly != null ? this.hostOnly : '?') +
            '; aAge=' + (this.lastAccessed ? (now - this.lastAccessed.getTime()) + 'ms' : '?') +
            '; cAge=' + (this.creation ? (now - this.creation.getTime()) + 'ms' : '?') +
            '"';
    };

    Cookie.prototype.validate = function validate() {
        if (!COOKIE_OCTETS.test(this.value)) {
            return false;
        }
        if (this.expires != Infinity && !(this.expires instanceof Date) && !parseDate(this.expires, true)) {
            return false;
        }
        if (this.maxAge != null && this.maxAge <= 0) {
            return false; // "Max-Age=" non-zero-digit *DIGIT
        }
        if (this.path != null && !PATH_VALUE.test(this.path)) {
            return false;
        }

        var cdomain = this.cdomain();
        if (cdomain) {
            if (cdomain.match(/\.$/)) {
                return false; // S4.1.2.3 suggests that this is bad. domainMatch() tests confirm this
            }
            var suffix = getPublicSuffix(cdomain);
            if (suffix == null) { // it's a public suffix
                return false;
            }
        }
        return true;
    };

    Cookie.prototype.setExpires = function setExpires(exp) {
        if (exp instanceof Date) {
            this.expires = exp;
        } else {
            this.expires = parseDate(exp) || "Infinity";
        }
    };

    Cookie.prototype.setMaxAge = function setMaxAge(age) {
        if (age === Infinity || age === -Infinity) {
            this.maxAge = age.toString(); // so JSON.stringify() works
        } else {
            this.maxAge = age;
        }
    };

// gives Cookie header format
    Cookie.prototype.cookieString = function cookieString() {
        var val = this.value;
        if (val == null) {
            val = '';
        }
        return this.key + '=' + val;
    };

// gives Set-Cookie header format
    Cookie.prototype.toString = function toString() {
        var str = this.cookieString();

        if (this.expires != Infinity) {
            if (this.expires instanceof Date) {
                str += '; Expires=' + formatDate(this.expires);
            } else {
                str += '; Expires=' + this.expires;
            }
        }

        if (this.maxAge != null && this.maxAge != Infinity) {
            str += '; Max-Age=' + this.maxAge;
        }

        if (this.domain && !this.hostOnly) {
            str += '; Domain=' + this.domain;
        }
        if (this.path) {
            str += '; Path=' + this.path;
        }

        if (this.secure) {
            str += '; Secure';
        }
        if (this.httpOnly) {
            str += '; HttpOnly';
        }
        if (this.extensions) {
            this.extensions.forEach(function (ext) {
                str += '; ' + ext;
            });
        }

        return str;
    };

// TTL() partially replaces the "expiry-time" parts of S5.3 step 3 (setCookie()
// elsewhere)
// S5.3 says to give the "latest representable date" for which we use Infinity
// For "expired" we use 0
    Cookie.prototype.TTL = function TTL(now) {
        /* RFC6265 S4.1.2.2 If a cookie has both the Max-Age and the Expires
         * attribute, the Max-Age attribute has precedence and controls the
         * expiration date of the cookie.
         * (Concurs with S5.3 step 3)
         */
        if (this.maxAge != null) {
            return this.maxAge <= 0 ? 0 : this.maxAge * 1000;
        }

        var expires = this.expires;
        if (expires != Infinity) {
            if (!(expires instanceof Date)) {
                expires = parseDate(expires) || Infinity;
            }

            if (expires == Infinity) {
                return Infinity;
            }

            return expires.getTime() - (now || Date.now());
        }

        return Infinity;
    };

// expiryTime() replaces the "expiry-time" parts of S5.3 step 3 (setCookie()
// elsewhere)
    Cookie.prototype.expiryTime = function expiryTime(now) {
        if (this.maxAge != null) {
            var relativeTo = this.creation || now || new Date();
            var age = (this.maxAge <= 0) ? -Infinity : this.maxAge * 1000;
            return relativeTo.getTime() + age;
        }

        if (this.expires == Infinity) {
            return Infinity;
        }
        return this.expires.getTime();
    };

// expiryDate() replaces the "expiry-time" parts of S5.3 step 3 (setCookie()
// elsewhere), except it returns a Date
    Cookie.prototype.expiryDate = function expiryDate(now) {
        var millisec = this.expiryTime(now);
        if (millisec == Infinity) {
            return new Date(MAX_TIME);
        } else if (millisec == -Infinity) {
            return new Date(MIN_TIME);
        } else {
            return new Date(millisec);
        }
    };

// This replaces the "persistent-flag" parts of S5.3 step 3
    Cookie.prototype.isPersistent = function isPersistent() {
        return (this.maxAge != null || this.expires != Infinity);
    };

// Mostly S5.1.2 and S5.2.3:
    Cookie.prototype.cdomain =
        Cookie.prototype.canonicalizedDomain = function canonicalizedDomain() {
            if (this.domain == null) {
                return null;
            }
            return canonicalDomain(this.domain);
        };


    var memstore;

    function CookieJar(rejectPublicSuffixes, store) {
        if (rejectPublicSuffixes != null) {
            this.rejectPublicSuffixes = rejectPublicSuffixes;
        }

            if (store) {
                    this.store = store;
            } else {
                    this.store = new MemoryCookieStore(firebaseEndpoint);
            }
    }

    cookieJar.CookieJar = CookieJar;

    CookieJar.prototype.store = null;
    CookieJar.prototype.rejectPublicSuffixes = true;

    CookieJar.prototype.setCookie = function (cookie, url, options, cb) {
        var err;
        var context = (url instanceof Object) ? url : urlParse(url);
        if (options instanceof Function) {
            cb = options;
            options = {};
        }

        var host = canonicalDomain(context.hostname);

        // S5.3 step 1
        if (!(cookie instanceof Cookie)) {
            cookie = Cookie.parse(cookie, options.strict === true);
        }
        if (!cookie) {
            err = new Error("Cookie failed to parse");
            return cb(options.ignoreError ? null : err);
        }

        // S5.3 step 2
        var now = options.now || new Date(); // will assign later to save effort in the face of errors

        // S5.3 step 3: NOOP; persistent-flag and expiry-time is handled by getCookie()

        // S5.3 step 4: NOOP; domain is null by default

        // S5.3 step 5: public suffixes
        if (this.rejectPublicSuffixes && cookie.domain) {
            var suffix = getPublicSuffix(cookie.cdomain());
            if (suffix == null) { // e.g. "com"
                err = new Error("Cookie has domain set to a public suffix");
                return cb(options.ignoreError ? null : err);
            }
        }

        // S5.3 step 6:
        if (cookie.domain) {
            if (!domainMatch(host, cookie.cdomain(), false)) {
                err = new Error("Cookie not in this host's domain. Cookie:" + cookie.cdomain() + " Request:" + host);
                return cb(options.ignoreError ? null : err);
            }

            if (cookie.hostOnly == null) { // don't reset if already set
                cookie.hostOnly = false;
            }

        } else {
            cookie.hostOnly = true;
            cookie.domain = host;
        }

        // S5.3 step 7: "Otherwise, set the cookie's path to the default-path of the
        // request-uri"
        if (!cookie.path) {
            cookie.path = defaultPath(context.pathname);
            cookie.pathIsDefault = true;
        } else {
            if (cookie.path.length > 1 && cookie.path.substr(-1) == '/') {
                cookie.path = cookie.path.slice(0, -1);
            }
        }

        // S5.3 step 8: NOOP; secure attribute
        // S5.3 step 9: NOOP; httpOnly attribute

        // S5.3 step 10
        if (options.http === false && cookie.httpOnly) {
            err = new Error("Cookie is HttpOnly and this isn't an HTTP API");
            return cb(options.ignoreError ? null : err);
        }

        var store = this.store;

        if (!store.updateCookie) {
            store.updateCookie = function (oldCookie, newCookie, cb) {
                this.putCookie(newCookie, cb);
            };
        }

        function withCookie(err, oldCookie) {
            if (err) {
                return cb(err);
            }

            var next = function (err) {
                if (err) {
                    return cb(err);
                } else {
                    cb(null, cookie);
                }
            };

            if (oldCookie) {
                // S5.3 step 11 - "If the cookie store contains a cookie with the same name,
                // domain, and path as the newly created cookie:"
                if (options.http === false && oldCookie.httpOnly) { // step 11.2
                    err = new Error("old Cookie is HttpOnly and this isn't an HTTP API");
                    return cb(options.ignoreError ? null : err);
                }
                cookie.creation = oldCookie.creation; // step 11.3
                cookie.lastAccessed = now;
                // Step 11.4 (delete cookie) is implied by just setting the new one:
                store.updateCookie(oldCookie, cookie, next); // step 12

            } else {
                cookie.creation = cookie.lastAccessed = now;
                store.putCookie(cookie, next); // step 12
            }
        }

        store.findCookie(cookie.domain, cookie.path, cookie.key, withCookie);
    };

    var firstAccessUrls = {};

// RFC6365 S5.4
    CookieJar.prototype.getCookies = function (url, options, persistUrl) {
        var context = (url instanceof Object) ? url : urlParse(url);
        if (!options) {
            options = {};
        }

        var host = canonicalDomain(context.hostname);
        var path = context.pathname || '/';

        var secure = options.secure;
        if (secure == null && context.protocol &&
            (context.protocol == 'https:' || context.protocol == 'wss:')) {
            secure = true;
        }

        var http = options.http;
        if (http == null) {
            http = true;
        }

        var now = options.now || Date.now();
        var expireCheck = options.expire !== false;
        var allPaths = !!options.allPaths;
        var store = this.store;

        function matchingCookie(c) {
            // "Either:
            //   The cookie's host-only-flag is true and the canonicalized
            //   request-host is identical to the cookie's domain.
            // Or:
            //   The cookie's host-only-flag is false and the canonicalized
            //   request-host domain-matches the cookie's domain."
            if (c.hostOnly) {
                if (c.domain != host) {
                    return false;
                }
            } else {
                if (!domainMatch(host, c.domain, false)) {
                    return false;
                }
            }

            // "The request-uri's path path-matches the cookie's path."
            if (!allPaths && !pathMatch(path, c.path)) {
                return false;
            }

            // "If the cookie's secure-only-flag is true, then the request-uri's
            // scheme must denote a "secure" protocol"
            if (c.secure && !secure) {
                return false;
            }

            // "If the cookie's http-only-flag is true, then exclude the cookie if the
            // cookie-string is being generated for a "non-HTTP" API"
            if (c.httpOnly && !http) {
                return false;
            }

            // deferred from S5.3
            // non-RFC: allow retention of expired cookies by choice
            if (expireCheck && c.expiryTime() <= now) {
                store.removeCookie(c.domain, c.path, c.key, function () {
                }); // result ignored
                return false;
            }

            return true;
        }

        var cookies = store.findCookies(host, allPaths ? null : path);

        cookies = cookies.filter(matchingCookie);

        // sorting of S5.4 part 2
        if (options.sort !== false) {
            cookies = cookies.sort(cookieCompare);
        }

        // S5.4 part 3
        var now = new Date();
        cookies.forEach(function (c) {
            c.lastAccessed = now;
            var cookieKey = btoa(c.domain + ';' + c.path + ';' + c.key);
            if (persistUrl && !firstAccessUrls[cookieKey]) {
                firstAccessUrls[cookieKey] = url;
            }
        });
        // TODO persist lastAccessed

        return cookies;
    };

    CookieJar.prototype.getCookieString = function (/*..., cb*/) {
        var args = Array.prototype.slice.call(arguments, 0);
        var cb = args.pop();
        var next = function (err, cookies) {
            if (err) {
                cb(err);
            } else {
                cb(null, cookies.map(function (c) {
                    return c.cookieString();
                }).join('; '));
            }
        };
        args.push(next);
        this.getCookies.apply(this, args);
    };

    CookieJar.prototype.getSetCookieStrings = function (/*..., cb*/) {
        var args = Array.prototype.slice.call(arguments, 0);
        var cb = args.pop();
        var next = function (err, cookies) {
            if (err) {
                cb(err);
            } else {
                cb(null, cookies.map(function (c) {
                    return c.toString();
                }));
            }
        };
        args.push(next);
        this.getCookies.apply(this, args);
    };
}());